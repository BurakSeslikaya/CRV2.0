package sample;

import Cashiers.Cashier;
/*  NOTLAR
 *  TextArea kullanÄ±lacak help iÃ§in                                             => YAPILDI
 * Menude bir seÃ§eneÄŸi tÄ±klanamaz yapmak iÃ§in value.setDiseable() kullan
 * Listview kasiyer seÃ§mede kullanÄ±labilir, goods satÄ±ÅŸÄ±nda da kullanÄ±labilir   => YAPILDI
 *  YARABBELALEMÄ°NÄ°M GÃœNDE EN AZ 8 SAAT YAZILIMLA UÄ�RAÅ�MAKTAN GÃ–ZÃœM Ã‡IKTI FÄ°NALLERDEN SONRA RAHAT RAHAT C# 'A BAÅ�LAYIP BÄ°R DE C# Ä°Ã‡Ä°N 8 SAATLER HARCAMAYI SEN NASÄ°P ET RABBÄ°M
 */
import Cashiers.CashierService;
import MyControls.MyControl;
import MyControls.MyMessages;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;


public class Main extends Application{
    @Override


    public void start(Stage firstStage) {
        filesCreat();
       // CashierService.getCashiersFromTXTtoList();
        CashierService.getCashiersFromTXTtoListPass();

        GridPane pane =MyControl.MyGridPane();
        pane.setAlignment(Pos.CENTER);
        pane.setPadding(new Insets(10,10,10,10)); // pane'in kenarlarÄ±ndaki boÅŸluklarÄ± ayarladÄ±k
        pane.setHgap(5);
        pane.setVgap(5);
        Label lbname = MyControl.MyLabelLime("Username: "); //lbname.setTextFill(Color.RED); yaparsan username yazÄ±sÄ± kÄ±rmÄ±zÄ± yazÄ±lÄ±r  => Gerek kalmadÄ± bu notlara:D
        GridPane.setConstraints(lbname, 0, 0);  // Bu ve alt satÄ±r bu iÅŸe yarÄ±yor => pane.add(lbname,0,0);
        pane.getChildren().add(lbname);
        TextField  tfName = MyControl.MyTextFieldRedText("sherlockholmes");

        pane.add(tfName, 1 ,0);				//birinci sÃ¼tun sÄ±fÄ±rÄ±ncÄ± satÄ±r
        Label lpassword = MyControl.MyLabelLime("Password: ");
        pane.add(lpassword, 0 , 1);
        PasswordField pfpassword = MyControl.MyPasswordFieldRedText("221B");
        pane.add(pfpassword, 1 , 1);

        Button btLogIn = MyControl.MyButtonSM("LogIn");
        pane.add(btLogIn, 1, 3);
        btLogIn.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub

               // CashierService.CashierId = "611";

                // ALTTAKÄ° KISMI SON RÃ–TUÅ�LAR YAPARKEN AÃ‡, KONTROL ET, HOCAYA Ã–YLE AT


				String a ;
				a = tfName.getText();

				String b ;
				b = pfpassword.getText();


				try {


					if(!CashierService.CashierFind(a,b)) {
						tfName.clear();
						pfpassword.clear();
					}
					else{
                        firstStage.close();
                        if(CashierService.CashierFind(a, b)) {
                        	
                            HomeGUI.window();
                        }

                    }



				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					 MyMessages.errorMessage("CAUTION", "Kisi bulunurken hata gelisti.\n" +e.getMessage());
				}


            }
        });

        Button btHelp = MyControl.MyButtonSK("Help");
        pane.add(btHelp, 1, 3);

        btHelp.setOnAction(e -> MyMessages.Help());

        GridPane.setHalignment(btHelp, HPos.RIGHT); // GridPane.setHalignment(btHelp, HPos.RIGHT); yazmÄ±ÅŸÄ±m ama neden Ã¶yle yazdÄ±m hatÄ±rlamÄ±yorum

        Scene sc = new Scene(pane);
        //	sc.getStylesheets().add("C:\\Users\\HPPC\\Desktop\\JavaFX\\PROJE\\src\\application\\application.css"); // => neden iÅŸe yaramÄ±yor?
        firstStage.setScene(sc);
        firstStage.setTitle("Entrance ");
        firstStage.show();

    }
private static void filesCreat(){
        FileCreatControl("Goods.txt");
        FileCreatControl("Customers.txt");
        FileCreatControl("Passw.txt");
        FileCreatControl("SalesListAll.txt");
        FileCreatControl("Authorization.txt");
}
    private static void FileCreatControl(String fileName){

            File f = new File(fileName);
            if (!f.exists()) {
                try {
                    f.createNewFile();
                } catch (IOException e) {

                }
            }

        }

    public static void main(String[] args) {
        launch(args);
    }

}
