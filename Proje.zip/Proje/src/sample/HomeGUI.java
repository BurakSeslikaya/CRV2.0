package sample;

import Cashiers.CashierGUI;
import Cashiers.CashierService;
import Customer.CustomerGUI;
import Customer.CustomerService;
import Message.MessageSend;
import Message.seeMessages;
import MyControls.MyControl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import Authorizations.AuthGui;
import Authorizations.Authorization;
import MyControls.MyMessages;
import Products.ProductGUI;
import Products.ProductService;
import Sales.Report;
import Sales.Sales;
import Sales.Rebate;
import Sales.SalesService;
import Sales.SalesGUI;

/*NOTLAR
 * 	Centera satış eklenecek -> pane.setcenter
 *
 *  BURAK 56. satırı okuman gerek
 *
 *
 */

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class HomeGUI { // kasiyer veya managera göre düzenlemeler yapılacak bu sadece ikisinde de
    // bulunup etkinleştirilecek/etkinleştirilemeyecek tüm şeyler

    public static void window() {

        ProductService.getProductsFromTXTtoList(); // txt'deki ürün listesini çekiyor
        CustomerService.getCustomerFromTXTtoList();
        SalesService.getSalesFromTXTtoList();
// kasiyerlerin sayfasını yazarken 	Cashiers.setDisable(true); yap veya kisi0,kisi1,kisi2 için yap. SAnırım yetkilendirmede kullanılabilir
        Stage kisi = new Stage(); // kasiyer veya managera göre düzenlemeler yapılacak

        kisi.setTitle("Anasayfa");
        // kisi.setFullScreen(true);
        kisi.setWidth(1000);
        kisi.setHeight(600);
        Menu Cashiers = new Menu("_Cashiers");
        MenuItem CashierAdding = new MenuItem("Add...");
        MenuItem CashierRemoving = new MenuItem("Remove...");
        MenuItem CashierList = new MenuItem("Cashiers.");
        Cashiers.getItems().addAll(CashierAdding, CashierRemoving);
        Cashiers.getItems().add(new SeparatorMenuItem()); // remove ile edit arasına çizgi çektik
        Cashiers.getItems().add(CashierList);

        Menu Goods = new Menu("Products");
        MenuItem producList = new MenuItem("List");
        MenuItem allGoods = new MenuItem("All infos Products'");            //Degisiklik yapamaz ama listeyi görebilir
        Goods.getItems().add(producList);
        Goods.getItems().add(new SeparatorMenuItem()); // çizgi çektik
        Goods.getItems().add(allGoods);

        Menu menudekiReport = new Menu("Report.");
        MenuItem report = new MenuItem("Get Report");
        menudekiReport.getItems().add(report);
        
        ArrayList<String> aryl = new ArrayList<String>();
        try {
        	aryl = Message.Messages.headLines(Integer.parseInt(CashierService.CashierId));
        }
        catch(Exception e) {
        	e.printStackTrace();
        }
        int uncheckedMessages = 0;
        String uncheckedMessagesS = "";
        for(int f = 2; f < aryl.size(); f = f + 3) {
        	if((aryl.get(f)).equals("1"))
        		uncheckedMessages++;
        }
        if(uncheckedMessages > 0) {
        	uncheckedMessagesS = Integer.toString(uncheckedMessages);
        }
        Menu Message = new Menu("_Messages " + uncheckedMessagesS); 
        MenuItem MessageAdding = new MenuItem("Send Message...");
        MenuItem MessageSeeing = new MenuItem("See Your Meassages...");
        Message.getItems().addAll(MessageAdding, MessageSeeing);

        Menu menudekiCustomer= new Menu("Customers");
        MenuItem itemCustomer = new MenuItem("List");
        menudekiCustomer.getItems().add(itemCustomer);
        
        Menu authorization = new Menu("_Authorization");
        MenuItem autho = new MenuItem("Edit Authorizations");
        authorization.getItems().add(autho);
        
        ArrayList<String> aut = new ArrayList<String>();
        try {
        	aut = Authorization.log(Integer.parseInt(CashierService.CashierId));
        }
        catch(Exception e) {
        	e.printStackTrace();
        }
        
        if(aut.get(0).equals("0"))
        	CashierAdding.setDisable(true);
        if(aut.get(1).equals("0"))
        	CashierRemoving.setDisable(true);
        if(aut.get(2).equals("0")) 
        	CashierList.setDisable(true);
        if(aut.get(3).equals("0"))
        	producList.setDisable(true);
        if(aut.get(4).equals("0"))
        	allGoods.setDisable(true);
        if(aut.get(5).equals("0"))
        	report.setDisable(true);
        if(aut.get(6).equals("0"))
        	MessageAdding.setDisable(true);
        if(aut.get(7).equals("0"))
        	autho.setDisable(true);
        
        MessageAdding.setOnAction(new EventHandler<ActionEvent>() {
        	public void handle(ActionEvent arg0) {
        		MessageSend.SendGui();
        	}
		});
        
        MessageSeeing.setOnAction(new EventHandler<ActionEvent>() {
        	public void handle(ActionEvent arg0) {
        		try {
					seeMessages.SeeGui();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
        	}
		});
        
        authorization.setOnAction(new EventHandler<ActionEvent>() {
        	public void handle(ActionEvent arg0) {
        		AuthGui.firstAuthGui();
        	}
		});

        MenuBar bar = MyControl.MyMenuBar();
        bar.getMenus().addAll(Cashiers, Goods, menudekiReport, menudekiCustomer, Message, authorization);
        BorderPane pane = MyControl.MyBorderPane();
        pane.setTop(bar);
        pane.setCenter(SalesList());
        pane.setBottom(bottomHbox());

        CashierAdding.setOnAction(e -> CashierGUI.CashierAdd() ); // Cashierdaki add kısmı

        CashierRemoving.setOnAction(e -> CashierGUI.CashierRemove() );

        CashierList.setOnAction(e -> CashierGUI.CashierList() );

        producList.setOnAction(e -> { ProductGUI.ProductList(); });

        report.setOnAction(new EventHandler<ActionEvent>() { // rapor ekranını getirmeli
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub

                try {
                    Report.rapor();
                } catch (ParseException exception) {
                    MyMessages.errorMessage("Bir sey oldu", "Rapor getirilirken parse ex oldu");
                    exception.printStackTrace();
                } catch (Exception exception) {
                    MyMessages.errorMessage("Bir sey oldu", "Rapor getirilirken bir seyler ters gitti...\n" + exception.getMessage());
                }
            }
        });

        allGoods.setOnAction(e -> { ProductGUI.AllGoods(); });      //Eper txt haline benzer görmek isterse burayı kullanır

        itemCustomer.setOnAction(e-> CustomerGUI.CustomerListWait());
        Scene sc = new Scene(pane, 350, 500);
        kisi.setScene(sc);
        kisi.show();
    }

    public static Label lbTutarFiyatla = new Label();

    public static void LabelTutarBagla() {  // Anlık satış yapıldıktan sonra toplam fiyatı anasayfaya ekliyor
        Double tutarDouble = SalesService.SalesListTotalToday();
        String tutarString2f = String.format("%.2f", tutarDouble);
        lbTutarFiyatla.setText(tutarString2f + "TL");
        //lbTutarFiyatla.setText(String.valueOf(SalesService.SalesListTotalToday()));
    }

    private static HBox bottomHbox() {
        Label lbTutarYaziyla = MyControl.MyLabelUnderlined("TOPLAM TUTAR: ");
        lbTutarFiyatla = MyControl.MyLabelYellowGreen();
        HBox pencere = new HBox(13);
        pencere.setPadding(new Insets(13, 13, 13, 13));
        pencere.setPrefHeight(50);

        Button btAddSales = MyControl.MyButtonSM("Add sales");
        Button btRebateSales = MyControl.MyButtonSK("Rebate sales");
        Button btCustomerSales = MyControl.MyButtonSK("Cust. sales");
        pencere.getChildren().addAll(btAddSales, btRebateSales,btCustomerSales);


        pencere.setMargin(lbTutarYaziyla, new Insets(5, 5, 5, 400));
        pencere.setMargin(lbTutarFiyatla, new Insets(5, 5, 5, 5));

        pencere.getChildren().addAll(lbTutarYaziyla, lbTutarFiyatla);
        LabelTutarBagla();
        btAddSales.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                try {

                    SalesGUI.sale();
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        });
        btRebateSales.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                try {
                    Rebate.rebate();
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                    MyMessages.errorMessage("ERROR", "There is sth wrong with rebating..");
                }
            }
        });
        btCustomerSales.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
                try {
                    CustomerGUI.wanted = true;

                    CustomerGUI.CustomerListWait();
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                    MyMessages.errorMessage("ERROR", "There is sth wrong with rebating..");
                }
            }
        });
        pencere.setAlignment(Pos.BOTTOM_LEFT);
        //pencere.setFillHeight(false);
        return pencere;
    }

    public static HBox SalesList() {
        HBox hbox = new HBox();

        Stage primaryStage = MyControl.MyStage("AlisVeris");
        TableView<Sales> table = new TableView<>();

        TableColumn<Sales, String> columnR = MyControl.MyTableColumn("Type");
        TableColumn<Sales, String> column1 = MyControl.MyTableColumn("Name");
        TableColumn<Sales, Double> column3 = MyControl.MyTableColumn2("Price");
        TableColumn<Sales, Double> column4 = MyControl.MyTableColumn2("Amount");
        TableColumn<Sales, Double> column5 = MyControl.MyTableColumn("ProductTotal");
        TableColumn<Sales, Date> column6 = MyControl.MyTableColumn("date");
        SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");

        column6.setCellFactory(column -> {
            return new TableCell<Sales, Date>() {
                @Override
                protected void updateItem(Date item, boolean empty) {
                    super.updateItem(item, empty);

                    if (item == null || empty) {
                        setText(null);
                    } else {
                        setText(formatter.format(item));

                    }
                }
            };
        });

        table.getColumns().addAll(columnR, column1, column3, column4, column5, column6); // Kolonları ekledik
        // getForGoodsEdit();
        table.setItems(SalesService.salesList);
        hbox.setAlignment(Pos.CENTER);
        hbox.getChildren().addAll(table);
        hbox.setFillHeight(true);


        return hbox;
    }

}
