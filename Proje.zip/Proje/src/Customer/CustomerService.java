package Customer;

import MyControls.MyMessages;

import Products.Products;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class CustomerService {
    public static String CustomerId = "";
    public static ObservableList<Customer> customers = null;

    public static Customer CustomerBul(double CustomerId) {
        for (Customer c : customers) {
            if (c.getCustomerId() == (CustomerId)) {
                return c;
            }
        }
        return null;
    }

    public static ObservableList<Customer> getCustomerFromTXTtoList() {
        // txt'den çekilen bilgileri customer'a atıyor
        customers = FXCollections.observableArrayList();

        int i = 0;
        ArrayList<String> list = null ;
        try {
           list = Customers.get();
            Customer musteri = new Customer();

           for (String s : list) {
                i = i + 1;

                if (i == 1) {
                    musteri = new Customer();
                    musteri.setName(s);
                } else if (i == 2) {
                    musteri.setAge(s);
                } else if (i == 3) {
                    musteri.setNumber(s);
                } else if (i == 4) {
                    musteri.setEmail(s);
                }else if(i == 5){
                    musteri.setCustomerIdString(s);
                    customers.add(musteri);
                    i = 0;
                }

            }

        } catch (Exception e) {
            e.printStackTrace();
            MyMessages.errorMessage("ERROR", "CustomerService getCustomerFromTXTtoList() methodu! \n" + e.getMessage() );
        }

        return customers;

    }



    public static boolean addCustomer(String name, String number, String email, String age) {
        try {
            boolean varmi = false;
            for (Customer s : customers) {
                if (s.getNumber().equals(number)) {
                    varmi = true;
                }
            }
            if (varmi == false) {

                Customer ekle = new Customer();
                ekle.setNumber(number);
                ekle.setName(name);
                ekle.setAge(age);
                ekle.setEmail(email);
             //   customers.add(ekle);
                Customers.Create(name,age,number,email);

                return true;
            } else {
                MyMessages.errorMessage("ATTENTION", "You Cannot Add Not-Unique Customer. Please check the number.");
                return false;
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return false;
        }

    }




    public static boolean CustomerListesiKaydet() {

        // eski dosyayı yedekle
        DosyaSil();
        // product listesini kaydet
        for (Customer c : customers) {
            try {
                Customers.Create(c.getName(),c.getAge(),c.getNumber(),c.getEmail());
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

        return true;
    }

    private static void DosyaSil() {
        // dosya 2 varsa sil dosyayı dosya yedek yap yedeklemiş olursun hataya karşı
        // bir şeyi yanlışlıkla sildiysen dosyayedekte eski hali var :)
        File f = new File("CustomersYedek.txt");
        if (f.exists()) {
            f.delete();
        }
        File f2 = new File("Customers.txt");
        if (f2.exists()) {
            f2.renameTo(f);
            try {
                f2.createNewFile();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

        }

    }
}
