package Customer;

public class Customer { // benim clasım
    //  String name, String age, String number, String email
    private String age;
    private String number;
    private String email;
    private double CustomerId;
    private String name;


    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public double getCustomerId() {
        return CustomerId;
    }

    public void setCustomerId(double customerId) {
        CustomerId = customerId;
    }
    public void setCustomerIdString(String customerId) {
        CustomerId = Double.valueOf(customerId);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
