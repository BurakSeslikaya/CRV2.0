package Customer;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;

public class Customers {

    //    0 HATA!!!!!   1 BAŞARI İLE OLUŞTURULDU
    public static int Create(String name, String age, String number, String email) throws Exception {
        File file = new File("Customers.txt");
        BufferedReader bfr = new BufferedReader(new FileReader(file));
        ArrayList<String> arl = new ArrayList<String>();
        String oldValues;
        while((oldValues = bfr.readLine()) != null){
            arl.add(oldValues);
        }
        bfr.close();
        boolean a;
        if((a = arl.contains(email)) == true ) {
            return 0; //    Bu kullanıcı önceden oluşturulmuş.
        }
        if((a = arl.contains(number)) == true) {
            return 0;
        }
        else {
            BufferedWriter writing = new BufferedWriter(new FileWriter(file));
            int size;
            size = arl.size();
            String tm, fnl;
            for(int f = 0; f < size; f++) {
                tm = arl.get(f);
                writing.write(tm);
                writing.newLine();
            }
            writing.write(name);
            writing.newLine();
            writing.write(age);
            writing.newLine();
            writing.write(number);
            writing.newLine();
            writing.write(email);
            writing.newLine();
            if(size  == 0) {
                writing.write("6161");
            }
            else {
                size = Integer.parseInt(arl.get(size - 1));
                size++;
                fnl = Integer.toString(size);
                writing.write(fnl);
            }
            writing.newLine();
            writing.close();
            return 1;  //  Kullanıcı başarı ile oluşturuldu.

        }
    }

    // BÜTÜN MÜŞTERİ BİLGİLERİNİN OLDUĞU BİR ARRAY LİST GÖNDERİYO
    public static ArrayList<String> get() throws Exception{
        File file = new File("Customers.txt");
        BufferedReader bfrd = new BufferedReader(new FileReader(file));
        ArrayList<String> arl = new ArrayList<String>();
        String a;
        while((a = bfrd.readLine()) != null) {
            arl.add(a);
        }
        bfrd.close();
        return arl;
    }

    // 0 GİRİLİRSE AYNI KALIR
    public static int edit(String id, String newName, String newAge, String newNumber, String newEmail) throws Exception {
        File file = new File("Customers.txt");
        BufferedReader bfrd = new BufferedReader(new FileReader(file));
        ArrayList<String> arl = new ArrayList<String>();
        String oldValues;
        boolean a;
        while((oldValues = bfrd.readLine()) != null){
            arl.add(oldValues);
        }
        bfrd.close();
        String r = "0";
        int g, y, f, t;
        g = arl.indexOf(id);
        if(newName == r) {
            newName = arl.get(g - 4);
        }
        if(newAge == r) {
            newAge = arl.get(g - 3);
        }
        if(newNumber == r) {
            newNumber = arl.get(g - 2);
        }
        if(newEmail == r) {
            newEmail = arl.get(g - 1);
        }
        ArrayList<String> wlist = new ArrayList<String>();
        f = arl.size();
        y = g;
        g = g - 4;
        for(t = 0; t < f; t++) {
            if(t == g) {
                if(g == (y)) {
                    g = g - 5;
                }
                g++;
                continue;
            }
            wlist.add(arl.get(t));
        }
        wlist.add(newName);
        wlist.add(newAge);
        wlist.add(newNumber);
        wlist.add(newEmail);
        wlist.add(id);
        BufferedWriter bft = new BufferedWriter(new FileWriter(file));
        t = wlist.size();
        for(int d = 0; d < t; d++) {
            bft.write(wlist.get(d));
            bft.newLine();
        }
        bft.close();
        return 1;
    }
}