package Customer;

import MyControls.MyControl;
import Products.Products;
import Sales.SalesGUI;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class CustomerGUI {
    public static boolean wanted = false;
    public static Customer wantedCustomer = null;

    public static void CustomerListWait() {

        Stage primaryStage = MyControl.MyStage("CUSTOMER LIST");
        TableView<Customer> table = new TableView<>();

        TableColumn<Customer, String> column1 = MyControl.MyTableColumn("CustomerId");
        TableColumn<Customer, String> column2 = MyControl.MyTableColumn("name");
        TableColumn<Customer, String> column5 = MyControl.MyTableColumn("number");
        TableColumn<Customer, String> column3 = MyControl.MyTableColumn("email");
        TableColumn<Customer, String> column4 = MyControl.MyTableColumn("age");


        table.getColumns().addAll(column1, column2, column5, column3, column4); // Kolonları ekledik
        // getForGoodsEdit();
        table.setItems(CustomerService.customers); //customer lsitesini table'a aktardı.  Bir kere bağlafığın için  aşağıdakilere gerek kalmadı

        TextField inputName = MyControl.MyTextFieldRedText("name");
        TextField inputNumber = MyControl.MyTextFieldRedText("number");
        TextField inputEMail = MyControl.MyTextFieldRedText("email");
        TextField inputAge = MyControl.MyTextFieldRedText("age");
        inputAge.setMinWidth(190);

        Button addButton = new Button("Add");
        Button deleteButton = new Button("Delete");
        HBox hbox = new HBox(13);
        hbox.setPadding(new Insets(10, 10, 10, 10));
        hbox.setSpacing(10);
        hbox.getChildren().addAll(inputName, inputNumber, inputEMail, inputAge, addButton, deleteButton);

        table.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                if (event.isPrimaryButtonDown() && event.getClickCount() == 2) {
                    if (wanted) {

                        wantedCustomer = table.getSelectionModel().getSelectedItem();
                        CustomerService.CustomerId = String.valueOf(wantedCustomer.getCustomerId());
                        wanted = false;// arama bitince  hata olmasin diye false yaptık
                        SalesGUI.sale();
                        primaryStage.close();
                    }
                }
            }
        });

        addButton.setOnAction(E -> {

            String name = inputName.getText();
            String age = inputAge.getText();
            String number = inputNumber.getText();
            String email = inputEMail.getText();
            if (CustomerService.addCustomer(name, number, email, age)) {
                CustomerService.getCustomerFromTXTtoList();
                table.setItems(CustomerService.customers);
            }
            inputName.clear();
            inputAge.clear();
            inputNumber.clear();
            inputEMail.clear();

        });

        deleteButton.setOnAction(D -> {
            ObservableList<Customer> selectedCustomer = table.getSelectionModel().getSelectedItems();
            selectedCustomer.forEach(CustomerService.customers::remove);
            CustomerService.CustomerListesiKaydet();
        });

        VBox vbox = new VBox();
        vbox.getChildren().addAll(table, hbox);
        Scene sc = new Scene(vbox);
        table.setStyle("-fx-background-color: #282828");
        vbox.setStyle("-fx-background-color: #282828");
        primaryStage.setResizable(false);
        primaryStage.setScene(sc);
        primaryStage.showAndWait();

    }

}
