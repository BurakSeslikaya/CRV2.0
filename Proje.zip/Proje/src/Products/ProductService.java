package Products;

import MyControls.MyMessages;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

public class ProductService {

    // urun listesi işlemleri bunun üzerinden yapıyor
    public static ObservableList<Products> products = null;

    public static Products UrunBul(String barkod) {
        for (Products s : products) {
            if (s.getBarcode().equals(barkod)) {
                return s;
            }
        }
        return null;
    }

    public static ObservableList<Products> getProductsFromTXTtoList() {
        // txt'den çekilen bilgileri product'a atıyor
        products = FXCollections.observableArrayList();

        int i = 0;
        Scanner s;
        try {
            s = new Scanner(new File("Goods.txt"));

            Products urun = new Products();

            while (s.hasNext()) {
                i = i + 1;

                if (i == 1) {
                    urun = new Products();
                    urun.setName(s.nextLine());
                } else if (i == 2) {
                    urun.setBarcode(s.nextLine());
                } else if (i == 3) {
                    urun.setPrice(s.nextLine());
                } else if (i == 4) {
                    urun.setQuantity(s.nextLine());
                    products.add(urun);
                    i = 0;
                }

            }
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return products;

    }

    public static boolean addProduct(String name, String barcode, String price, String quantity) {
        try {
            boolean varmi = false;
            for (Products s : products) {
                if (s.getBarcode().equals(barcode)) {
                    varmi = true;
                }
            }
            if (varmi == false) {

                Products ekle = new Products();
                ekle.setBarcode(barcode);
                ekle.setName(name);
                ekle.setPrice(price);
                ekle.setQuantity(quantity);
                products.add(ekle);
                Goods.creat(name, barcode, price, quantity);
                return true;
            } else {
                MyMessages.errorMessage("ATTENTION", "You Cannot Add Not-Unique Product. Please check the barcode.");
                return false;
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return false;
        }

    }

    public static boolean UrunListesiKaydet() {

        // eski dosyayı yedekle
        DosyaSil();
        // product listesini kaydet
        for (Products s : products) {
            try {
                Goods.creat(s.getName(), s.getBarcode(), s.getPriceString(), s.getQuantityString());
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

        return true;
    }

    private static void DosyaSil() {
        // dosya 2 varsa sil dosyayı dosya yedek yap yedeklemiş olursun hataya karşı
        // bir şeyi yanlışlıkla sildiysen dosyayedekte eski hali var :)
        File f = new File("GoodsYedek.txt");
        if (f.exists()) {
            f.delete();
        }
        File f2 = new File("Goods.txt");
        if (f2.exists()) {
            f2.renameTo(f);
            try {
                f2.createNewFile();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

        }

    }

}
