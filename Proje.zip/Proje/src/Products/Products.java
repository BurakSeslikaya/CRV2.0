package Products;

public class Products {
    private String name;
    private String barcode;
    private double price;
    private double quantity;

    public Products() {

    }
    public Products(String name, double price, double quantity) {
        this.name = name;
        this.price = price;
        this.quantity = quantity;
    }

    public Products(String name, String barcode, double price, double quantity) {
        this.name = name;
        this.barcode = barcode;
        this.price = price;
        this.quantity = quantity;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public double getPrice() {
        return price;
    }

    public String getPriceString() {
        return String.valueOf(price);
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setPrice(String price) {

        this.price = Double.valueOf(price);
    }

    public double getQuantity() {
        return quantity;
    }

    public String getQuantityString() {
        return String.valueOf(quantity);
    }

    public void setQuantity(double quantity) {
        this.quantity = quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = Double.valueOf(quantity);
    }

}
