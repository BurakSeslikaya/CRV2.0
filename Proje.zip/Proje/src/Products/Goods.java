package Products;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;

public class Goods {

    // barcod fiyat adet kontrol edilmeli hepsi sadece sayı olmalı
    public static int creat(String name, String barcod, String fiyat, String adet ) throws Exception {
        File file = new File("Goods.txt");
        BufferedReader bfrd = new BufferedReader(new FileReader(file));
        ArrayList<String> arl = new ArrayList<String>();
        String oldValues;
        boolean a, b;
        while((oldValues = bfrd.readLine()) != null){
            arl.add(oldValues);
        }
        bfrd.close();
        if(((a = arl.contains(name))&&(b = arl.contains(barcod))) == false) {
            BufferedWriter bft = new BufferedWriter(new FileWriter(file));
            int t;
            t = arl.size();
            for(int d = 0; d < t; d++) {
                bft.write(arl.get(d));
                bft.newLine();
            }
            bft.write(name + "\n");
            bft.write(barcod + "\n");
            bft.write(fiyat);
            bft.newLine();
            bft.write(adet);
            bft.newLine();
            bft.close();
            return 1;   // Done
        }
        else {
            return 0;  //Already exists
        }
    }

    // 0 girilirse bütün ürünleri gönderir
    public static ArrayList<String> get(String barcode) throws Exception {
        File file = new File("Goods.txt");
        BufferedReader bfrd = new BufferedReader(new FileReader(file));
        ArrayList<String> arl = new ArrayList<String>();
        String a;
        while((a = bfrd.readLine()) != null) {
            arl.add(a);
        }
        if(barcode == "0") {
            bfrd.close();
            return arl;
        }
        else {
            int ab;
            ArrayList<String> arl2 = new ArrayList<String>();
            ab = arl.indexOf(barcode);
            if(ab == -1) {
                arl2.add("-1");
                bfrd.close();
                return arl2;
            }
            ab = ab - 1;
            for(int y = 0; y < 4; y++) {
                arl2.add(arl.get(ab));
                ab++;
            }
            bfrd.close();
            return arl2;
        }
    }

    // 0 hata 1 tamamlandı       ****** new barcod new fiyat...... 0 ise eskisi ile aynı
    public static int edit(String oldBarcod, String newName, String newBarcod, String newFiyat, String newAdet) throws Exception {
        File file = new File("Goods.txt");
        BufferedReader bfrd = new BufferedReader(new FileReader(file));
        ArrayList<String> arl = new ArrayList<String>();
        String oldValues;
        boolean a;
        while((oldValues = bfrd.readLine()) != null){
            arl.add(oldValues);
        }
        bfrd.close();
        String r = "0";
        if(newBarcod == r) {
            newBarcod = oldBarcod;
        }
        int g, y, f, t;
        g = arl.indexOf(oldBarcod);
        g--;
        if(newName == r) {
            newName = arl.get(g);
        }
        if(newFiyat == r) {
            newFiyat = arl.get(g + 2);
        }
        if(newAdet == r) {
            newAdet = arl.get(g + 3);
        }
        if((a = arl.contains(oldBarcod)) == false) {
            return 0;
        }
        else {
            ArrayList<String> wlist = new ArrayList<String>();
            f = arl.size();
            y = g;
            for(t = 0; t < f; t++) {
                if(t == g) {
                    if(g == (y + 3)) {
                        g = g - 5;
                    }
                    g++;
                    continue;
                }
                wlist.add(arl.get(t));
            }
            wlist.add(newName);
            wlist.add(newBarcod);
            wlist.add(newFiyat);
            wlist.add(newAdet);
            BufferedWriter bft = new BufferedWriter(new FileWriter(file));
            t = wlist.size();
            for(int d = 0; d < t; d++) {
                bft.write(wlist.get(d));
                bft.newLine();
            }
            bft.close();
            return 1;
        }
    }
}