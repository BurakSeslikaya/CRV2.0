package Products;

import MyControls.MyControl;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.stage.Stage;

import java.io.File;
import java.util.Scanner;

public class ProductGUI {

    public static boolean wanted =false;
    public static Products wantedProduct=null;

    public static void ProductList() {

        Stage primaryStage = MyControl.MyStage("PRODUCT LIST");
        TableView<Products> table = new TableView<>();

        TableColumn<Products, String> column1 = MyControl.MyTableColumn("Name");
        TableColumn<Products, String> column2 = MyControl.MyTableColumn("Barcode");
        TableColumn<Products, String> column3 = MyControl.MyTableColumn("Price");
        TableColumn<Products, String> column4 = MyControl.MyTableColumn("Quantity");


        table.getColumns().addAll(column1, column2, column3, column4); // Kolonları ekledik
        // getForGoodsEdit();
        table.setItems(ProductService.products); //peoduct lsitesini table'a aktardı.  Bir kere bağlafığın için  aşağıdakilere gerek kalmadı

        TextField inputName = MyControl.MyTextFieldRedText("name : elma");
        TextField inputBarcode = MyControl.MyTextFieldRedText("barcode : 1234567890123");
        inputBarcode.setMinWidth(190);
        TextField inputPrice = MyControl.MyTextFieldRedText("price(TL/kg) : 3,59");
        TextField inputQuantity = MyControl.MyTextFieldRedText("quntity : 123");

        Button addButton = new Button("Add");
        Button deleteButton = new Button("Delete");
        HBox hbox = new HBox(13);
        hbox.setPadding(new Insets(10, 10, 10, 10));
        hbox.setSpacing(10);
        hbox.getChildren().addAll(inputName, inputBarcode, inputPrice, inputQuantity, addButton, deleteButton);

        table.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                if (event.isPrimaryButtonDown() && event.getClickCount() == 2) {
                    if (wanted){
                        wantedProduct=table.getSelectionModel().getSelectedItem();
                        wanted=false;// arama bitince  hata olmasin diye false yaptık
                        primaryStage.close();
                    }
                }
            }
        });

        addButton.setOnAction(E -> {
            String name = inputName.getText();
            String barcode = inputBarcode.getText();
            String price = inputPrice.getText();
            String quantity = inputQuantity.getText();
            if (ProductService.addProduct(name, barcode, price, quantity)) {
            }
            inputName.clear();
            inputBarcode.clear();
            inputPrice.clear();
            inputQuantity.clear();

        });

        deleteButton.setOnAction(D -> {
            ObservableList<Products> selectedGood = table.getSelectionModel().getSelectedItems();
             selectedGood.forEach(ProductService.products::remove); //ürün products'tan siliniyor
            ProductService.UrunListesiKaydet();
        });

        VBox vbox = new VBox();
        vbox.getChildren().addAll(table, hbox);
        Scene sc = new Scene(vbox);
        table.setStyle("-fx-background-color: #282828");
        vbox.setStyle("-fx-background-color: #282828");
        primaryStage.setResizable(false);
        primaryStage.setScene(sc);
        primaryStage.show();

    }

    public static void ProductListWait() {

        Stage primaryStage = MyControl.MyStage("PRODUCT LIST");
        TableView<Products> table = new TableView<>();

        TableColumn<Products, String> column1 = MyControl.MyTableColumn("Name");
        TableColumn<Products, String> column2 = MyControl.MyTableColumn("Barcode");
        TableColumn<Products, String> column3 = MyControl.MyTableColumn("Price");
        TableColumn<Products, String> column4 = MyControl.MyTableColumn("Quantity");


        table.getColumns().addAll(column1, column2, column3, column4); // Kolonları ekledik
        // getForGoodsEdit();
        table.setItems(ProductService.products); //peoduct lsitesini table'a aktardı.  Bir kere bağlafığın için  aşağıdakilere gerek kalmadı

        TextField inputName = MyControl.MyTextFieldRedText("name : elma");
        TextField inputBarcode = MyControl.MyTextFieldRedText("barcode : 1234567890123");
        inputBarcode.setMinWidth(190);
        TextField inputPrice = MyControl.MyTextFieldRedText("price(TL/kg) : 3,59");
        TextField inputQuantity = MyControl.MyTextFieldRedText("quntity : 123");

        Button addButton = new Button("Add");
        Button deleteButton = new Button("Delete");
        HBox hbox = new HBox(13);
        hbox.setPadding(new Insets(10, 10, 10, 10));
        hbox.setSpacing(10);
        hbox.getChildren().addAll(inputName, inputBarcode, inputPrice, inputQuantity, addButton, deleteButton);

        table.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                if (event.isPrimaryButtonDown() && event.getClickCount() == 2) {
                    if (wanted){
                        wantedProduct=table.getSelectionModel().getSelectedItem();
                        wanted=false;// arama bitince  hata olmasin diye false yap
                        primaryStage.close();
                    }
                }
            }
        });

        addButton.setOnAction(E -> {

            String name = inputName.getText();
            String barcode = inputBarcode.getText();
            String price = inputPrice.getText();
            String quantity = inputQuantity.getText();
            if (ProductService.addProduct(name, barcode, price, quantity)) {

            }
            inputName.clear();
            inputBarcode.clear();
            inputPrice.clear();
            inputQuantity.clear();

        });

        deleteButton.setOnAction(D -> {
            ObservableList<Products> selectedGood = table.getSelectionModel().getSelectedItems();

            selectedGood.forEach(ProductService.products::remove); //ürün products'tan siliniyor

            ProductService.UrunListesiKaydet();
        });

        VBox vbox = new VBox();
        vbox.getChildren().addAll(table, hbox);
        Scene sc = new Scene(vbox);
        table.setStyle("-fx-background-color: #282828");
        vbox.setStyle("-fx-background-color: #282828");
        primaryStage.setResizable(false);
        primaryStage.setScene(sc);
        primaryStage.showAndWait();

    }
    public static void AllGoods(){
        Stage firstStage = MyControl.MyStage("All Informations about Goods");
        TextArea areaOfGood = new TextArea();
        areaOfGood.setMinSize(250, 250);
        try {
            Scanner s = new Scanner(new File("Goods.txt"));
            while (s.hasNext()) {
                areaOfGood.appendText(s.nextLine() + "\n");
            }
        } catch (Exception ex) {

            ex.printStackTrace();
        }
        GridPane gp = new GridPane();
        gp.setStyle("-fx-background-color: #282828");
        Label lb = new Label("For each 4 rows;\n1. row is the name of the good\n2.row is the barcode of the good\n3. row is the price of the good\n4. row is the quantity of the good");
        lb.setTextFill(Color.LIME);
        lb.setFont(Font.font("times new roman", FontPosture.ITALIC, 13));
        gp.add(lb, 0, 0);
        gp.add(areaOfGood, 0, 1);
        Scene sc = new Scene(gp);
        firstStage.setResizable(false);
        firstStage.setScene(sc);
        firstStage.show();
    }
}
