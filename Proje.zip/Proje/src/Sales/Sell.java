package Sales;

import Products.Goods;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.ListIterator;
import java.util.Stack;

public class Sell {

    /*
     * Array list good =
     *                      **** bunlar son halinde ekleniyor----> cashier id
     * customer id<------ ********
     * barcode
     * kaç tane üstteki üründen
     * barcode
     * kaç tane ...
     * <ENDOFRECİEPT>
     * ...
     * ...
     * ...
     * <ENDOFDAY>
     */

    public static void sellRecord(String CustomerId, String CashierId, ArrayList<String> Good) throws Exception {
        File file = new File("Records.txt");
        BufferedReader bfrd = new BufferedReader(new FileReader(file));
        ArrayList<String> arl = new ArrayList<String>();
        String oldValues;
        while((oldValues = bfrd.readLine()) != null){
            arl.add(oldValues);
        }
        bfrd.close();
        BufferedWriter bfw = new BufferedWriter(new FileWriter(file));
        int t, y, k, l, r;
        t = arl.size();
        for(int d = 0; d < t; d++) {
            bfw.write(arl.get(d));
            bfw.newLine();
        }
        bfw.write(CashierId);
        bfw.newLine();
        bfw.write(CustomerId);
        bfw.newLine();
        t = Good.size();
        String barcode, second, third;
        for(int f = 0; f < t; f++) {
            r = 0;
            barcode = Good.get(r);
            if((barcode.equals("null")) == true) {
                break;
            }
            f = f + 1;
            second = Good.get((r + 1));
            Good.remove(barcode);
            Good.remove(second);
            bfw.write(barcode);
            bfw.newLine();
            if((Good.contains(barcode)) == true) {
                y = Good.indexOf(barcode);
                Good.remove(y);
                third = Good.get(y);
                Good.remove(y);
                k = Integer.parseInt(second);
                l = Integer.parseInt(third);
                k = k + l;
                second = Integer.toString(k);
                bfw.write(second);
            }
            else {
                bfw.write(second);
            }
            bfw.newLine();
            ArrayList<String> arl2 = new ArrayList<String>();
            arl2 = Goods.get(barcode);
            String abc;
            int frst, scnd;
            abc = arl2.get(3);
            frst = Integer.parseInt(abc);
            scnd = Integer.parseInt(second);
            frst = frst - scnd;
            abc = Integer.toString(frst);
            Goods.edit(barcode, "0", "0", "0", abc);
            arl2.clear();
        }
        bfw.write("<ENDOFRECİEPT>");
        bfw.newLine();
        bfw.close();
    }


    /*eğer hmday 0 girilirse en baştan itibaren alınacak       **eğer who 0 girilirse herkesin kaydı
     *
     * who = satın alan
     * bywho = satıcı
     */

    public static Stack<String> GetSellRecords(int Howmday, String who, String byWho) throws Exception {
        File file = new File("Records.txt");
        BufferedReader bfrd = new BufferedReader(new FileReader(file));
        Stack<String> stack = new Stack<String>();
        Stack<String> stack2 = new Stack<String>();
        String abcd = "";
        int days = 0, h = 0;
        while((abcd = bfrd.readLine()) != null) {
            if((abcd.equals("<ENDOFDAY>")) == true) {
                days++;
            }
            stack.add(abcd);
        }
        bfrd.close();
        if((byWho.equals("0")) == true) {
            if((who.equals("0")) == true) {
                if(Howmday == 0) {
                    return stack;
                }
                else {
                    if(Howmday > days) {
                        return stack;
                    }
                    else {
                        ListIterator<String> ListIterator = stack.listIterator(stack.size());
                        String endod;
                        while (h != (Howmday + 1)) {
                            endod = ListIterator.previous();
                            if((endod.equals("<ENDOFDAY>")) == true)
                                h++;
                            if(h == (Howmday + 1)) {
                                while(ListIterator.hasPrevious()) {
                                    ListIterator.remove();
                                    ListIterator.previous();
                                }
                                ListIterator.remove();
                                break;
                            }
                        }
                        while(ListIterator.hasNext()) {
                            endod = ListIterator.next();
                            stack2.add(endod);
                        }
                        return stack2;
                    }
                }
            }
            else {
                if(((Howmday == 0) || (Howmday > days)) == true) {
                    ListIterator<String> lsit = stack.listIterator();
                    String temp;
                    while(lsit.hasNext()) {
                        temp = lsit.next();
                        if(temp.equals(who) == true) {
                            lsit.previous();
                            temp = lsit.previous();
                            while(temp.equals("<ENDOFRECİEPT>") != true) {
                                temp = lsit.next();
                                stack2.add(temp);
                            }
                        }
                        if(temp.equals("<ENDOFDAY>") == true) {
                            stack2.add(temp);
                        }
                    }
                    return stack2;
                }
                else {
                    ListIterator<String> lsit = stack.listIterator();
                    String temp;
                    int day = 0;
                    while(lsit.hasNext()) {
                        temp = lsit.next();
                        if(temp.equals("<ENDOFDAY>")) {
                            day++;
                        }
                        if(day == (days - Howmday)) {
                            while(lsit.hasNext()) {
                                temp = lsit.next();
                                if(temp.equals(who) == true) {
                                    lsit.previous();
                                    temp = lsit.previous();
                                    while(temp.equals("<ENDOFRECİEPT>") != true) {
                                        temp = lsit.next();
                                        stack2.add(temp);
                                    }
                                }
                                if(temp.equals("<ENDOFDAY>") == true) {
                                    stack2.add(temp);
                                }
                            }
                        }
                    }
                    return stack2;
                }
            }
        }
        else {
            if((Howmday == 0) || (Howmday > days)) {
                if((who.equals("0")) == true) {
                    ListIterator<String> liit = stack.listIterator();
                    String qb;
                    while(liit.hasNext() == true) {
                        qb = liit.next();
                        if(qb.equals(byWho)) {
                            while(qb.equals("<ENDOFRECİEPT>") != true) {
                                stack2.add(qb);
                                qb = liit.next();
                            }
                            stack2.add("<ENDOFRECİEPT>");
                        }
                        if(qb.equals("<ENDOFDAY>")) {
                            stack2.add(qb);
                        }
                    }
                    return stack2;
                }
                else {
                    ListIterator<String> liit = stack.listIterator();
                    String qb;
                    while(liit.hasNext() == true) {
                        qb = liit.next();
                        if(qb.equals(byWho)) {
                            qb = liit.next();
                            if(qb.equals(who)) {
                                liit.previous();
                                qb = liit.previous();
                                while(qb.equals("<ENDOFRECİEPT>") != true) {
                                    qb = liit.next();
                                    stack2.add(qb);
                                }
                            }
                        }
                        if(qb.equals("<ENDOFDAY>")) {
                            stack2.add(qb);
                        }
                    }
                    return stack2;
                }
            }
            else {
                ListIterator<String> liit = stack.listIterator();
                String qb;
                int cnt = 0;
                while(cnt != (days - Howmday)) {
                    qb = liit.next();
                    if(qb.equals("<ENDOFDAY>")) {
                        cnt++;
                    }
                    liit.remove();
                }
                if((who.equals("0")) == true) {
                    while(liit.hasNext() == true) {
                        qb = liit.next();
                        if(qb.equals(byWho)) {
                            stack2.add(qb);
                            while(qb.equals("<ENDOFRECİEPT>") != true) {
                                qb = liit.next();
                                stack2.add(qb);
                            }
                        }
                        if(qb.equals("<ENDOFDAY>")) {
                            stack2.add(qb);
                        }
                    }
                    return stack2;
                }
                else {
                    while(liit.hasNext() == true) {
                        qb = liit.next();
                        if(qb.equals(byWho)) {
                            qb = liit.next();
                            if(qb.equals(who)) {
                                liit.previous();
                                qb = liit.previous();
                                while(qb.equals("<ENDOFRECİEPT>") != true) {
                                    qb = liit.next();
                                    stack2.add(qb);
                                }
                            }
                        }
                        if(qb.equals("<ENDOFDAY>")) {
                            stack2.add(qb);
                        }
                    }
                    return stack2;
                }
            }
        }
    }

    //
    public static void nextDay() throws Exception {
        File file = new File("Records.txt");
        BufferedReader bfrd = new BufferedReader(new FileReader(file));
        ArrayList<String> arl = new ArrayList<String>();
        String oldValues;
        while((oldValues = bfrd.readLine()) != null){
            arl.add(oldValues);
        }
        bfrd.close();
        BufferedWriter bfw = new BufferedWriter(new FileWriter(file));
        int t, y;
        t = arl.size();
        for(int d = 0; d < t; d++) {
            bfw.write(arl.get(d));
            bfw.newLine();
        }
        bfw.write("<ENDOFDAY>");
        bfw.newLine();
        bfw.close();
    }
}