package Sales;

import MyControls.MyControl;
import MyControls.MyMessages;
import Sales.Sales;
import Sales.SalesService;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.stage.Stage;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Report {

    //public static ObservableList<Sales> salesListReport = null;  //belli tarihin aranacağı liste

    public static HBox rapor() throws Exception {
        SalesService.salesListReport = FXCollections.observableArrayList(); // Listeyi sıfırlıyor ekrana gelen
        VBox vbox = new VBox();
        Stage primaryStage = MyControl.MyStage("Rapor");

        TableView<Sales> table = new TableView<>();
        TableColumn<Sales, String> columnR = MyControl.MyTableColumn("Type");
        TableColumn<Sales, Double> columnC = MyControl.MyTableColumn("CustomerId");
        TableColumn<Sales, String> column1 =MyControl.MyTableColumn("Name");
        TableColumn<Sales, Double> column3 =MyControl.MyTableColumn2("Price");
        TableColumn<Sales, Double> column4 =MyControl.MyTableColumn2("Amount");
        TableColumn<Sales, Double> column5 =MyControl.MyTableColumn("ProductTotal");
        TableColumn<Sales, Date> column6 =MyControl.MyTableColumn("date");
        SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy");

        column6.setCellFactory(column -> {
            return new TableCell<Sales, Date>() {
                @Override
                protected void updateItem(Date item, boolean empty) {
                    super.updateItem(item, empty);

                    if (item == null || empty) {
                        setText(null);
                    } else {
                        setText(formatter.format(item));

                    }
                }
            };
        });

        table.getColumns().addAll( columnR,columnC, column1, column3, column4,column5,column6); // Kolonları ekledik

        table.setItems(SalesService.salesListReport);

        TextField tfTarih = MyControl.MyTextField("TARİH ARAMA YAP");
        Date dt = new Date();
        SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy");
        tfTarih.setText(format.format(dt));

        Button btFind = MyControl.MyButtonSK("Find");
        HBox hbox = new HBox(13);
        hbox.setPadding(new Insets(10, 10, 10, 10));
        hbox.setSpacing(10);
        hbox.getChildren().addAll(tfTarih, btFind);

        Label lbTutarYaziyla = MyControl.MyLabelUnderlined("TOPLAM TUTAR: ");
        Label lbTutarFiyatla =MyControl.MyLabelYellowGreen();

        hbox.getChildren().addAll(lbTutarYaziyla, lbTutarFiyatla);
        hbox.setMargin(lbTutarYaziyla, new Insets(5,5,5,600));
        hbox.setMargin(lbTutarFiyatla, new Insets(5,5,5,5));
        lbTutarFiyatla.setFont(Font.font("times new roman", FontPosture.ITALIC, 17));

        btFind.setOnAction(E -> {
            // table.refresh();
            try {
                String dateString = tfTarih.getText();

                Date date = formatDate(dateString); // Date date = new SimpleDateFormat("dd.MM.yyyy ").parse(dateString);

                SalesService.getReportList(date);
                table.setItems(SalesService.salesListReport);
                int adet = SalesService.salesListReport.size();

                if(adet==0){
                    MyMessages.errorMessage("CAUTION","Kayit bulunamadi");
                    return;
                }

                Double tutarDouble = SalesService.SalesListReportTotal();
                String tutarString2f=String.format("%.2f",tutarDouble);
                lbTutarFiyatla.setText(tutarString2f + "TL");

            }
            catch (Exception e) {

                // TODO Auto-generated catch block
                e.printStackTrace();
                MyMessages.errorMessage("Yok", "Report 98.satır catch bloğunda hata\n"+ e.getMessage());
            }
        });

        vbox.getChildren().addAll(table, hbox);

        Scene sc = new Scene(vbox);
        table.setStyle("-fx-background-color: #282828");
        vbox.setStyle("-fx-background-color: #282828");
       // primaryStage.setResizable(false);
        primaryStage.setScene(sc);

        primaryStage.show();

        return hbox;
    }
    private static Date formatDate(String date1) throws ParseException {
        Date format = new SimpleDateFormat("dd.MM.yyyy").parse(date1);
        return format;
    }
    private static String formatYear(Date date) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy");
        return format.format(date);
    }

    private static String formatMonth(Date date) {
        SimpleDateFormat format = new SimpleDateFormat("MM");
        return format.format(date);
    }

    private static String formatDay(Date date) {
        SimpleDateFormat format = new SimpleDateFormat("dd");
        return format.format(date);
    }
}









