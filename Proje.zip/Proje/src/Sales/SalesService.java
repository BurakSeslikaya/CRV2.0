package Sales;

import Products.Goods;
import Products.Products;
import Products.ProductService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;


public class SalesService {

    public static ObservableList<Sales> salesListReport = null;  //belli tarihin aranacağı liste
    public static ObservableList<Sales> salesList = null;        // SAnırım bugün apılan tüm satışların listesi ama emin değilim kontrol et
    public static ObservableList<Sales> salesListAll = null;     // Bütün ürünlerin olduğu liste sannrım

    public static void getSalesFromTXTtoList() {
        salesListReport = FXCollections.observableArrayList();
        salesList = FXCollections.observableArrayList();
        salesListAll = FXCollections.observableArrayList();
        getSalesFromTXTtoListGet();
        // txt belgesinden tümünü saleslistall'a ceker


        Date dt = new Date();  // Bugünün tarihi
        String year = formatYear(dt);    //tarihin yılını alıyor string'e çeviriyor
        String month = formatMonth(dt);//tarihin ayını alıyor string'e çeviriyor
        String day = formatDay(dt);//tarihin gününü alıyor string'e çeviriyor
        String findYear = "";
        String findMonth = "";
        String findDay = "";

        for (Sales c : salesListAll) {  // Bıugünün alışverişlerini getiriyor
            if (c.getDate() == null) {
                continue;
            }
            findYear = formatYear(c.getDate());
            findMonth = formatMonth(c.getDate());
            findDay = formatDay(c.getDate());
            if (year.equals(findYear) && month.equals(findMonth) && day.equals(findDay)) {
                salesList.add(c);
            }
        }

    }

    public static void getReportList(Date dt) { // Date dt sayesinde belli bir tarihin bilgilerini salesListAll'dan çekiyor salesListReport'a ekliyor
        salesListReport = FXCollections.observableArrayList();

        String year = formatYear(dt);    //tarihin yılını alıyor string'e çeviriyor
        String month = formatMonth(dt);  //tarihin ayını alıyor string'e çeviriyor
        String day = formatDay(dt);      //tarihin gününü alıyor string'e çeviriyor
        String findYear = "";
        String findMonth = "";
        String findDay = "";

        for (Sales c : salesListAll) {  // Aranan tarihin alışverişlerini getiriyor
            if (c.getDate() == null) {
                continue;
            }
            findYear = formatYear(c.getDate());
            findMonth = formatMonth(c.getDate());
            findDay = formatDay(c.getDate());
            if (year.equals(findYear) && month.equals(findMonth) && day.equals(findDay)) {
                salesListReport.add(c);
            }
        }
        int i = salesListReport.size();
    }

    public static double SalesListReportTotal() {          // RApor sayfasına aranan tarihin ürünlerinin piyatlarını salesListReport'tan çekip topluyor
        double total = 0.0;
        for (Sales s : salesListReport) {
            try {
                total += s.getProductTotal();
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        return total;
    }
    public static String SalesRebateNowTotal( ) { //Anlık alışverişlerin ürünlerinin fiyatlarının toplamını vermesi gerek ama bir şeyleri hatalı yapıyorum...
        double total = 0.00d;

        for (Sales s : Rebate.satilacakOrSilinecek) {
            try {
                total += s.getProductTotal();
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        String totalString = String.valueOf(total);
        return totalString;
    }public static String SalesNowTotal( ) { //Anlık alışverişlerin ürünlerinin fiyatlarının toplamını vermesi gerek ama bir şeyleri hatalı yapıyorum...
        double total = 0.00d;

        for (Sales s : SalesGUI.satilacakOrSilinecek) {
            try {
                total += s.getProductTotal();
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        String totalString = String.valueOf(total);
        return totalString;
    }
    public static double SalesListTotalToday() { // Bugün yapılan tüm alışverişlerin fiyat toplamını salesList'i tarayıp topluyor
        double total = 0.00d;
        for (Sales s : salesList) {
            try {
                total += s.getProductTotal();
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        return total;
    }

    public static void getSalesFromTXTtoListGet() {
        // txt'den bilgileri çekiyor salesListAll'a ekliyor

        int i = 0;

        try {
            Scanner s;
            String str = "";
            s = new Scanner(new File("SalesListAll.txt"));

            Sales urun = new Sales();
            while (s.hasNext()) {
                i = i + 1;
                if (i == 1) {
                    urun = new Sales();
                    urun.setName(s.nextLine());
                } else if (i == 2) {
                    urun.setBarcode(s.nextLine());
                } else if (i == 3) {
                    str = s.nextLine();
                    Date date = formatDate(str);
                    urun.setDate(date);
                } else if (i == 4) {
                    str = s.nextLine();
                    urun.setCustomerId(Double.valueOf(str));
                } else if (i == 5) {
                    str = s.nextLine();
                    urun.setCashierId(str);
                } else if (i == 6) {
                    str = s.nextLine();
                    urun.setAmount(str);
                } else if (i == 7) {
                    str = s.nextLine();
                    urun.setPrice(str);
                } else if (i == 8) {
                    str = s.nextLine();
                    urun.setProductTotal(str);
                }else if (i == 9) {
                    str = s.nextLine();
                    urun.setType(str);
                    salesListAll.add(urun);
                    i = 0;
                }

            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    private static Date formatDate(String date1) throws ParseException {
        Date format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss").parse(date1);
        return format;
    }

    private static String formatYear(Date date) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy");
        return format.format(date);
    }

    private static String formatMonth(Date date) {
        SimpleDateFormat format = new SimpleDateFormat("MM");
        return format.format(date);
    }

    private static String formatDay(Date date) {
        SimpleDateFormat format = new SimpleDateFormat("dd");
        return format.format(date);
    }


    public static void SalesAdd(ObservableList<Sales> saleAddList) { // satılacak olan ürünü fişe ekler
        try {

            salesList.addAll(saleAddList);
            salesListAll.addAll(saleAddList);
            for (Sales s : saleAddList) {
                try {
                    s.setType("Sale");
                    addSalesTxt(s);
                    ProductAmountUpdate(s);
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();

        }

    }
    public static void SalesAddRebate(ObservableList<Sales> saleAddList) { // satılacak olan ürünü fişe ekler
        try {

            salesList.addAll(saleAddList);
            salesListAll.addAll(saleAddList);
            for (Sales s : saleAddList) {
                try {
                    s.setType("Rebate");
                    addSalesTxt(s);
                    ProductAmountUpdate(s);
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();

        }

    }
    public static void addSalesTxt(Sales s) {
        Path p = Paths.get("SalesListAll.txt");
        String st = "";
        try {
            st = s.getName() + System.lineSeparator();
            Files.write(p, st.getBytes(), StandardOpenOption.APPEND);
            st = s.getBarcode() + System.lineSeparator();
            Files.write(p, st.getBytes(), StandardOpenOption.APPEND);

            SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");


            st = String.valueOf(formatter.format(s.getDate())) + System.lineSeparator();
            Files.write(p, st.getBytes(), StandardOpenOption.APPEND);

            st = String.valueOf(s.getCustomerId()) + System.lineSeparator();
            Files.write(p, st.getBytes(), StandardOpenOption.APPEND);

            st = String.valueOf(s.getCashierId()) + System.lineSeparator();
            Files.write(p, st.getBytes(), StandardOpenOption.APPEND);

            st = String.valueOf(s.getAmount()) + System.lineSeparator();
            Files.write(p, st.getBytes(), StandardOpenOption.APPEND);
            st = String.valueOf(s.getPrice()) + System.lineSeparator();
            Files.write(p, st.getBytes(), StandardOpenOption.APPEND);
            st = String.valueOf(s.getProductTotal()) + System.lineSeparator();
            Files.write(p, st.getBytes(), StandardOpenOption.APPEND);
            st = String.valueOf(s.getType()) + System.lineSeparator();
            Files.write(p, st.getBytes(), StandardOpenOption.APPEND);
        } catch (IOException e) {
            System.err.println(e);                                      // System.err writes to a file. ???? araştır %100 emin ol doğru mu değil mi

        }

    }
    private static void ProductAmountUpdate(Sales s){
       // ProductService.products
                for(Products p: ProductService.products){

                    try {
                        if (p.getBarcode().equals(s.getBarcode())) {
                            p.setQuantity(p.getQuantity() - s.getAmount());

                            Goods.edit(p.getBarcode(), p.getName(), "0", "0", p.getQuantityString());
                        }
                    }
                    catch (Exception e) {
                            e.printStackTrace();
                        }

                }

    }
}
