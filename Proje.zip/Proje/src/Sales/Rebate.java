package Sales;

import java.text.SimpleDateFormat;
import java.util.Date;

import MyControls.MyControl;
import MyControls.MyMessages;
import Products.Products;
import Products.ProductService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import sample.HomeGUI;

public class Rebate {
    public static ObservableList<Sales> satilacakOrSilinecek = null;

    public static boolean rebate() {
        satilacakOrSilinecek = FXCollections.observableArrayList();
        VBox vbox = new VBox();
        Stage primaryStage = MyControl.MyStage("AlisVeris");
        TableView<Sales> table = new TableView<>();

        TableColumn<Sales, String> column1 = MyControl.MyTableColumn("Name");
        TableColumn<Sales, Double> column3 = MyControl.MyTableColumn("Price");
        TableColumn<Sales, Double> column4 = MyControl.MyTableColumn("Amount");
        TableColumn<Sales, Double> column5 = MyControl.MyTableColumn("ProductTotal");
        TableColumn<Sales, Date> column6 = MyControl.MyTableColumn("date");
        SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");

        column6.setCellFactory(column -> {
            return new TableCell<Sales, Date>() {
                @Override
                protected void updateItem(Date item, boolean empty) {
                    super.updateItem(item, empty);

                    if (item == null || empty) {
                        setText(null);
                    } else {
                        setText(formatter.format(item));

                    }
                }
            };
        });

        table.getColumns().addAll(column1, column3, column4, column5, column6); // Kolonları ekledik
        // getForGoodsEdit();
        table.setItems(satilacakOrSilinecek);

        TextField tfbarcode = MyControl.MyTextField("barcode");
        Button btUrunuEkle = MyControl.MyButtonSK("Rebate the product");
        Button btUrunuSil = MyControl.MyButtonSM("Delete the product");
        TextField tfmiktar = MyControl.MyTextField("amount");
        Button btRebate = new Button("Rebate");
        HBox hbox = new HBox(13);
        hbox.setPadding(new Insets(10, 10, 10, 10));
        hbox.setSpacing(10);
        hbox.getChildren().addAll(tfbarcode, tfmiktar, btUrunuEkle, btUrunuSil, btRebate);


        Label lbTutarFiyatla = MyControl.MyLabelYellowGreen();
        Label lbTutarYaziyla = MyControl.MyLabelUnderlined("TOTAL PRICE: ");
        hbox.setMargin(lbTutarYaziyla, new Insets(5,5,5,5));
        hbox.setMargin(lbTutarFiyatla, new Insets(5,5,5,5));
        hbox.getChildren().addAll(lbTutarYaziyla, lbTutarFiyatla);

        btUrunuEkle.setOnAction(E -> {

            String barcode = tfbarcode.getText();

            try {
                Products urunAra = ProductService.UrunBul(barcode);
                if (urunAra != null) {
                    // urun bulununca yapılacak ıslemler

                    double kacTane = Double.valueOf(tfmiktar.getText());


                        String name = urunAra.getName();
                        double price = urunAra.getPrice();
                        double amount = (kacTane);
                        Sales sale = new Sales(name, barcode, price, amount*(-1), "0");
                        satilacakOrSilinecek.add(sale);

                        Double tutarDouble = Double.valueOf(SalesService.SalesRebateNowTotal());
                        String tutarString2d=String.format("%.2f",tutarDouble);
                        lbTutarFiyatla.setText(tutarString2d + "TL");

                        tfbarcode.clear();
                        tfmiktar.clear();


                } else {
                    MyMessages.errorMessage("CAUTION", "product couldn't be find");
                }

            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                //MyMessages.errorMessage("CAUTION", "urun getirilirken bir sorun oldu\n" + e.getMessage());
            }
        });

        btUrunuSil.setOnAction(D -> {
            ObservableList<Sales> selectedGood = table.getSelectionModel().getSelectedItems();
            selectedGood.forEach(satilacakOrSilinecek::remove);
        });


        btRebate.setOnAction(e -> {

            SalesService.SalesAddRebate(satilacakOrSilinecek);
            satilacakOrSilinecek = FXCollections.observableArrayList();
            primaryStage.close();
            HomeGUI.LabelTutarBagla();
        });


        vbox.getChildren().addAll(table, hbox);

        Scene sc = new Scene(vbox);
        table.setStyle("-fx-background-color: #282828");
        vbox.setStyle("-fx-background-color: #282828");
        primaryStage.setResizable(false);
        primaryStage.setScene(sc);

        primaryStage.show();

        return true;
    }


}
