package Sales;

import Cashiers.Cashier;
import Cashiers.CashierService;
import Customer.CustomerService;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Sales {
    private String name;
    private String barcode;
    private Date date;
    private double CustomerId;
    private double CashierId;
    private double amount;
    private double price;
    private double ProductTotal;
    private String type;

    public Sales() {

    }

    public Sales(String name,String barcode,double price,double amount,String CustomerId) {
        this.name = name;
        this.barcode = barcode;
        this.price = price;
        this.amount = amount;
        Double tutar = price*amount;
        this.ProductTotal = Math.round(tutar*100)/100.00;


        this.date =  new Date();
        this.CashierId = Double.valueOf(CashierService.CashierId);

        this.CustomerId = Double.valueOf(CustomerId);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }


    public double  getCustomerId() {
        return CustomerId;
    }

    public  String getCustomerIdString() {
        String CustomerID = String.valueOf(CustomerId);
        return CustomerID;
    }

    public void setCustomerId(double CustomerId) {
        this.CustomerId = CustomerId;
    }

    public void setCustomerId(String CustomerId) {
        this.CustomerId = Double.valueOf(CustomerId);
    }

    public double  getCashierId() {
        return CashierId;
    }

    public String getCashierIdString() {
        return String.valueOf(CashierId);
    }

    public void setCashierId(double CashierId) {
        this.CashierId = CashierId;
    }

    public void setCashierId(String CashierId) {
        this.CashierId = Double.valueOf(CashierId);
    }

    public double getPrice() {
        return price;
    }

    public String getPriceString() {
        return String.valueOf(price);
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setPrice(String price) {
        this.price = Double.valueOf(price);
    }

    public double getAmount() {
        return amount;
    }

    public String getQuantityString() {
        return String.valueOf(amount);
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public void setAmount(String quantity) {
        this.amount = Double.valueOf(quantity);
    }

    public double getProductTotal(){
        return ProductTotal;
    }

    public void setProductTotal(double ProductTotal) {
        this.ProductTotal = ProductTotal;
    }

    public void setProductTotal(String ProductTotal) {
        this.ProductTotal = Double.valueOf(ProductTotal);
    }

    public void setDate(Date date){
        this.date = date;
    }

    public Date getDate(){
        return this.date;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}



