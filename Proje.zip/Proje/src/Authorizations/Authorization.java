package Authorizations;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;

public class Authorization {
	
	
	public static ArrayList<String> log(int cashierId) throws Exception {
		File file = new File("Authorization.txt");
		BufferedReader bfr = new BufferedReader(new FileReader(file));
		ArrayList<String> arl = new ArrayList<String>();
		String oldValues;
		while((oldValues = bfr.readLine()) != null){
			if(oldValues.equals(Integer.toString(cashierId))) {
				for(int f = 0; f < 8; f++) {
					oldValues = bfr.readLine();
					arl.add(oldValues);
				}
				break;
			}
		}
		bfr.close();
		return arl;
	}
	
	
	public static void edit(int cashierId, ArrayList<String> newAuthorizations) throws Exception {
		File file = new File("Authorization.txt");
		BufferedReader bfr = new BufferedReader(new FileReader(file));
		ArrayList<String> arl = new ArrayList<String>();
		String oldValues;
		while((oldValues = bfr.readLine()) != null){
			arl.add(oldValues);
		}
		bfr.close();
		BufferedWriter bfrw = new BufferedWriter(new FileWriter(file));
		int size = arl.size();
		for(int f = 0; f < size; f++) {
			oldValues = arl.get(f);
			if(oldValues.equals(Integer.toString(cashierId))) {
				f = f + 9;
				continue;
			}
			bfrw.write(oldValues);
			bfrw.newLine();
		}
		bfrw.write(Integer.toString(cashierId));
		bfrw.newLine();
		for(int f = 0; f < 8; f++) {
			bfrw.write(newAuthorizations.get(f));
			bfrw.newLine();
		}
		bfrw.close();
	}
}