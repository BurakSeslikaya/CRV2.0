package Authorizations;

import java.util.ArrayList;

import Cashiers.Cashier;
import Cashiers.CashierService;
import MyControls.MyControl;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class AuthGui {
	
	
	public static void Gui(int Id, String name) {
		Stage stage = new Stage();
		stage.setTitle(name + " Authorization");
		
		Label label = new Label("Cashier Adding:   ");
		Label label1 = new Label("Cashier Removing: ");
		Label label2 = new Label("Cashier Editing:  ");
		Label label3 = new Label("Goods Aditing:    ");
		Label label4 = new Label("Good Information: ");
		Label label5 = new Label("Geting Report:    ");
		Label label6 = new Label("Sending Message:  ");
		Label label7 = new Label("Editing Authorizations: ");
		
		ArrayList<String> authlog2 = new ArrayList<String>();
		try {
			authlog2 = Authorization.log(Id);
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		
		ChoiceBox<String> chbx = choiceBoxes(authlog2, 0);
		ChoiceBox<String> chbx1 = choiceBoxes(authlog2, 1);
		ChoiceBox<String> chbx2 = choiceBoxes(authlog2, 2);
		ChoiceBox<String> chbx3 = choiceBoxes(authlog2, 3);
		ChoiceBox<String> chbx4 = choiceBoxes(authlog2, 4);
		ChoiceBox<String> chbx5 = choiceBoxes(authlog2, 5);
		ChoiceBox<String> chbx6 = choiceBoxes(authlog2, 6);
		ChoiceBox<String> chbx7 = choiceBoxes(authlog2, 7);
		
		VBox vbox2 = new VBox();
		HBox hbox3 = new HBox(3);
		HBox hbox4 = new HBox(3);
		
		Button bttn = new Button("Save");
		
		hbox3.getChildren().addAll(label, chbx, label1, chbx1, label2, chbx2, label3, chbx3);
		hbox4.getChildren().addAll(label4, chbx4, label5, chbx5, label6, chbx6, label7, chbx7);
		vbox2.getChildren().addAll(hbox3, hbox4, bttn);
		
		bttn.setOnAction(e ->{
			ArrayList<String> authlog = new ArrayList<String>();
			try {
				authlog = Authorization.log(Integer.parseInt(CashierService.CashierId));
				authlog = choiceboxes(chbx.getSelectionModel().getSelectedItem(), 0, authlog);
				authlog = choiceboxes(chbx1.getSelectionModel().getSelectedItem(), 1, authlog);
				authlog = choiceboxes(chbx2.getSelectionModel().getSelectedItem(), 2, authlog);
				authlog = choiceboxes(chbx3.getSelectionModel().getSelectedItem(), 3, authlog);
				authlog = choiceboxes(chbx4.getSelectionModel().getSelectedItem(), 4, authlog);
				authlog = choiceboxes(chbx5.getSelectionModel().getSelectedItem(), 5, authlog);
				authlog = choiceboxes(chbx6.getSelectionModel().getSelectedItem(), 6, authlog);
				authlog = choiceboxes(chbx7.getSelectionModel().getSelectedItem(), 7, authlog);
				Authorization.edit(Id, authlog);
			} catch (NumberFormatException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			stage.close();
		});
		
		hbox3.setSpacing(10);
		hbox3.setPadding(new Insets(10, 10, 10, 10));
		hbox4.setSpacing(10);
		hbox4.setPadding(new Insets(10, 10, 10, 10));
		vbox2.setPadding(new Insets(10, 10, 10, 10));
		vbox2.setSpacing(10);
        Scene sc = new Scene(vbox2);
        stage.setResizable(false);
        stage.setScene(sc);
        stage.show();
	}
	
	public static void firstAuthGui() {
		Stage stage = new Stage();
		
		TableView<Cashier> table2 = new TableView<Cashier>();

        TableColumn<Cashier, String> column1 = MyControl.MyTableColumn("Name");
        TableColumn<Cashier, String> column2 = MyControl.MyTableColumn("Password");
        TableColumn<Cashier, String> column3 = MyControl.MyTableColumn("SystemID");

        table2.getColumns().add(column1); // Kolonlar� ekledik
        table2.setItems(CashierService.cashiers);
		table2.setMaxHeight(150);
		table2.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
		
		table2.setOnMouseClicked(e ->{
			Cashier cashier = table2.getSelectionModel().getSelectedItem();
			String Id = cashier.getSystemID();
			String name = cashier.getName();
			stage.close();
			Gui(Integer.parseInt(Id), name);
		});
		
		VBox vbox = new VBox();
		vbox.getChildren().addAll(table2);
        vbox.setPadding(new Insets(10, 10, 10, 10));
        vbox.setSpacing(10);
        Scene sc = new Scene(vbox);
        stage.setResizable(false);
        stage.setScene(sc);
        stage.show();
	}
	
	public static ArrayList<String> choiceboxes(String selectedItem, int WhichColumn, ArrayList<String> oldAuth) throws Exception{
		if(selectedItem.equals("Authorized")) {
			oldAuth.set(WhichColumn, "1");
		}else {
			if(selectedItem.equals("Not Authorized")) {
				oldAuth.set(WhichColumn, "0");
			}
		}
		return oldAuth;
	}
	
	public static String cho(ArrayList<String> arr, int Whicone) {
		if(arr.get(Whicone).equals("1")) {
			return "Authorized";
		}else {
			return "Not Authorized";
		}
	}
	
	public static ChoiceBox<String> choiceBoxes(ArrayList<String> authlog, int nmbr) {
		ChoiceBox<String> chbx = new ChoiceBox<String>();
		chbx.getItems().addAll("Authorized", "Not Authorized");
		chbx.setValue(cho(authlog, nmbr));
		return chbx;
	}
}