package Message;

import java.util.ArrayList;

import Cashiers.CashierService;
import Cashiers.PasswordC;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class seeMessages {
	
	
	public static void SeeGui() throws Exception {
		Stage pencere = new Stage();
		
		TableView<Messages> table = new TableView<Messages>();

		TableColumn column11 = new TableColumn("From Who");
		column11.setCellValueFactory(new PropertyValueFactory<Messages, String>("byWho"));
		TableColumn column21 = new TableColumn("Subject");
		column21.setCellValueFactory(new PropertyValueFactory<Messages, Integer>("headline"));
		TableColumn column212 = new TableColumn("read");
		column212.setCellValueFactory(new PropertyValueFactory<Messages, Integer>("IsThR"));
		
		table.setMaxHeight(150);
		table.setMinHeight(150);
		column21.setMinWidth(150);
		
		table.setRowFactory(tv -> {
		    TableRow<Messages> row = new TableRow<>();
		    row.setOnMouseClicked(event -> {
		        if (! row.isEmpty() && event.getButton()==MouseButton.PRIMARY 
		             && event.getClickCount() == 2) {

		            Messages clickedRow = row.getItem();
		            try {
						theMessage((table.getItems().indexOf(clickedRow) + 1));
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
		        }
		    });
		    return row ;
		});
		
		table.setItems(getmessage());
		table.getColumns().addAll(column11, column21, column212);
		
		table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
		
		
		VBox vbox = new VBox();
        vbox.getChildren().add(table);
        vbox.setPadding(new Insets(10, 10, 10, 10));
        vbox.setSpacing(10);
        Scene sc = new Scene(vbox);
        pencere.setResizable(false);
        pencere.setScene(sc);
        pencere.show();
	}

	
	private static ObservableList<Messages> getmessage () throws Exception{
		ObservableList<Messages> olist = FXCollections.observableArrayList();
		String byWho, headline, read;
		ArrayList<String> aryl = new ArrayList<String>();
		aryl = Messages.headLines(Integer.parseInt(CashierService.CashierId));
		for(int f = 0; f < aryl.size(); f++) {
			byWho = aryl.get(f);
			f++;
			headline = aryl.get(f);
			f++;
			read = aryl.get(f);
			olist.add(new Messages(headline, Integer.parseInt(byWho), Integer.parseInt(read)));
		}
		return olist;
	}
	
	
	public static void theMessage(int whichMessage) throws Exception {
		ArrayList<String> message = new ArrayList<String>();
		message = Messages.getmessage(CashierService.CashierId, whichMessage);
		
		Label txt1 = new Label("Send By: ");
		Label txt2 = new Label("Subject: ");
		Label txt3 = new Label("The Message: ");
		Label txt4 = new Label(PasswordC.get(message.get(0)).get(0));
		Label txt5 = new Label(message.get(2));
		Label txt6 = new Label(message.get(4));
		
		Stage stage = new Stage();
		VBox vbox = new VBox();
		HBox hbox = new HBox(3);
		HBox hbox2 = new HBox(3);
		hbox.getChildren().addAll(txt1, txt4);
		hbox2.getChildren().addAll(txt2, txt5);
        vbox.getChildren().addAll(hbox, hbox2, txt3, txt6);
        vbox.setPadding(new Insets(10, 10, 10, 10));
        vbox.setSpacing(10);
        Scene sc = new Scene(vbox);
        stage.setResizable(false);
        stage.setScene(sc);
        stage.show();
	}
}