package Message;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;

public class Messages {
	private String headline;
	private int byWho;
	private int IsThR;
	
	public Messages() {
		
	}
	
	 public Messages(String headline,int byWho, int IsThR) {
		 	this.headline = headline;
	        this.byWho = byWho;
	        this.IsThR = IsThR;
	    }
	
	
	public String getHeadline() {
		return headline;
	}


	public void setHeadline(String headline) {
		this.headline = headline;
	}


	public int getByWho() {
		return byWho;
	}


	public void setByWho(int byWho) {
		this.byWho = byWho;
	}
	

	public int getIsThR() {
		return IsThR;
	}

	public void setIsThR(int isThR) {
		IsThR = isThR;
	}

	public static void createmessage(String message, String headLine, int byWho, int toWho) throws Exception {
		File file = new File("Message.txt");
		BufferedReader bfr = new BufferedReader(new FileReader(file));
		ArrayList<String> arl = new ArrayList<String>();
		String oldValues;
		while((oldValues = bfr.readLine()) != null){
			arl.add(oldValues);
		}
		bfr.close();
		BufferedWriter bfrw = new BufferedWriter(new FileWriter(file));
		int size = arl.size();
		for(int f = 0; f < size; f++) {
			oldValues = arl.get(f);
			bfrw.write(oldValues);
			bfrw.newLine();
		}
		bfrw.write(Integer.toString(byWho));
		bfrw.newLine();
		bfrw.write(Integer.toString(toWho));
		bfrw.newLine();
		bfrw.write(headLine);//		okunmadan �nce ekranda g�r�necek yaz�
		bfrw.newLine();
		bfrw.write("1");//         1 ise okunmam�� 0 ise okunmu�
		bfrw.newLine();
		bfrw.write(message);
		bfrw.newLine();
		bfrw.close();
	}
	
	
	public static ArrayList<String> headLines(int whos) throws Exception {
		File file = new File("Message.txt");
		BufferedReader bfr = new BufferedReader(new FileReader(file));
		ArrayList<String> arl = new ArrayList<String>();
		ArrayList<Integer> arl2 = new ArrayList<Integer>();
		ArrayList<String> returna = new ArrayList<String>();
		String oldValues;
		while((oldValues = bfr.readLine()) != null){
			arl.add(oldValues);
		}
		bfr.close();
		String who;
		int size = arl.size();
		for(int f = 1; f < size; f = f + 5) {
			who = arl.get(f);
			if(who.equals(Integer.toString(whos)))
				arl2.add(f - 1);
		}
		for(int f = 0; f < (arl2.size()); f++) {
			size = arl2.get(f);
			who = arl.get(size);
			returna.add(who);
			who = arl.get(size + 2);
			returna.add(who);
			who = arl.get(size + 3);
			returna.add(who);
		}
		return returna;
	}
	
	
	public static ArrayList<String> getmessage(String whosMessage, int whichMesssage) throws Exception {
		File file = new File("Message.txt");
		BufferedReader bfr = new BufferedReader(new FileReader(file));
		ArrayList<String> arl = new ArrayList<String>();
		ArrayList<Integer> arl2 = new ArrayList<Integer>();
		ArrayList<String> returna = new ArrayList<String>();
		String oldValues;
		while((oldValues = bfr.readLine()) != null){
			arl.add(oldValues);
		}
		bfr.close();
		String whos;
		int size = arl.size();
		for(int f = 1; f < size; f = f + 5) {
			whos = arl.get(f);
			if(whos.equals(whosMessage))
				arl2.add(f);
		}
		int which = arl2.get(whichMesssage - 1);
		for(int f = which - 1; f < (which + 4); f++) {
			returna.add(arl.get(f));
		}
		BufferedWriter bfrw = new BufferedWriter(new FileWriter(file));
		for(int f = 0; f < (arl.size()); f++) {
			if(f == which)
				arl.set((which + 2), "0");
			bfrw.write(arl.get(f));
			bfrw.newLine();
		}
		bfrw.close();
		return returna;
	}

}