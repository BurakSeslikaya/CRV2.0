package Message;

import java.util.ArrayList;
import java.util.List;

import Cashiers.Cashier;
import Cashiers.CashierService;
import MyControls.MyControl;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class MessageSend {

	
	public static void SendGui()  {
		Stage pencere = MyControl.MyStage("Cashiers");
		
		
		TableView<Cashier> table2 = new TableView<>();

        TableColumn<Cashier, String> column1 = MyControl.MyTableColumn("Name");
        TableColumn<Cashier, String> column2 = MyControl.MyTableColumn("Password");
        TableColumn<Cashier, String> column3 = MyControl.MyTableColumn("SystemID");

        table2.getColumns().add(column1); // Kolonlar� ekledik
        table2.setItems(CashierService.cashiers);
		table2.setMaxHeight(150);
		table2.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

		
		Label toWho = new Label("Choose the person you want to send this message: ");
		Label sub = new Label("Subject: ");
		Label lmessage = new Label("Message: ");
		TextField inputSub = MyControl.MyTextFieldRedText("Subject of your message: ");
		TextField inputmes = MyControl.MyTextFieldRedText("Your message");
		inputmes.setMinWidth(200);
		inputSub.setMinWidth(270);
		inputmes.setMinHeight(70);
		
		Button sendButton = new Button("Send");
		HBox hbox = new HBox(13);
		hbox.setPadding(new Insets(10, 10, 10, 10));
		hbox.setSpacing(10);
		hbox.getChildren().addAll(sub, inputSub);
		VBox vbox = new VBox();
        vbox.getChildren().addAll(toWho, table2, hbox, lmessage, inputmes, sendButton);
        vbox.setPadding(new Insets(10, 10, 10, 10));
        vbox.setSpacing(10);
        sendButton.setOnAction(e ->{
        	Cashier cashier = table2.getSelectionModel().getSelectedItem();
        	String id = cashier.getSystemID();
        	String subject = inputSub.getText();
        	String message = inputmes.getText();
        	try {
				Messages.createmessage(message, subject, Integer.parseInt(CashierService.CashierId), Integer.parseInt(id));
				
			} catch (NumberFormatException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
        	finally {
        		pencere.close();
        	}
        });
        Scene sc = new Scene(vbox);
        pencere.setResizable(false);
        pencere.setScene(sc);
        pencere.show();
	}
	
}
