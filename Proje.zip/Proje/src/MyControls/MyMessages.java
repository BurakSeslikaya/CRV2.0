package MyControls;

import Message.MessageSend;

/*  NOTLAR

SatÄ±r 98, send yapÄ±lÄ±nca oluÅŸacak iÅŸlemi girmeyi unutma!!!


 */

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class MyMessages {

    public static void errorMessage(String title, String message) {
        Stage window = MyControl.MyStage(title);
        window.initModality(Modality.APPLICATION_MODAL);
        Label label = MyControl.MyLabelLime(message);
        Button OKButton =MyControl.MyButtonSM("OKAY");
        OKButton.setOnAction(e -> window.close());
        VBox box = new VBox(13);
        box.getChildren().addAll(label, OKButton);
        box.setAlignment(Pos.CENTER);
        box.setStyle("-fx-background-color: #282828");
        Scene sc  = new Scene(box, 500,150);
        window.setScene(sc);
        window.showAndWait();
    }

    static boolean answer;
    public static boolean closing() {
        Stage window = new Stage();
        window.setTitle("R U Sure?");
        Label label =MyControl.MyLabelLime("Are you sure You want to exist?"); // EXIST DEÄ�IL EXIT OLACAK DEÄ�IÅ�TIRMEYI UNUTMA
        Button YesButton = MyControl.MyButtonSM("YES");
        Button NoButton = MyControl.MyButtonSK("NO");

        YesButton.setOnAction(e -> {
            answer = true;
            window.close();
        });
        NoButton.setOnAction(e -> {
            answer = false ;
            window.close();
        });

        VBox box = new VBox(13);
        box.getChildren().addAll(label, YesButton , NoButton);
        box.setAlignment(Pos.CENTER);
        box.setStyle("-fx-background-color: #282828");
        Scene sc  = new Scene(box, 300,300);
        window.setScene(sc);
        window.show();
        return answer;
    }
    public static void Help() {
        Stage errorWindow = MyControl.MyStage("HELP");
        errorWindow.setMinWidth(250);
        GridPane pane =MyControl.MyGridPane();
        pane.setAlignment(Pos.CENTER);
        Insets in = new Insets(10,10,10,10); // pane'in kenarlarÄ±ndaki boÅŸluklarÄ± ayarladÄ±k
        pane.setPadding(in);
        pane.setHgap(5);
        pane.setVgap(5);
        Label bilgi =MyControl.MyLabelLime("You can enter your problem to text area which is belove.");
        bilgi.setFont(Font.font("times new roman", FontPosture.ITALIC, 13));
        pane.add(bilgi,0,0);
        TextArea area = new TextArea();
        area.setPrefSize(300, 300);
        area.setStyle("-fx-text-inner-color: red"); //   => yazÄ±larÄ± kÄ±rmÄ±zÄ±ya Ã§evirdi

        pane.add(area,0,1);
        Label message =MyControl.MyLabelLime("Your message will be sent to the manager");
        message.setFont(Font.font("times new roman", FontPosture.ITALIC, 13));
        pane.add(message, 0, 2);
        Button btSend =MyControl.MyButtonSK("Send");//Button btSend = new Button("Send", new ImageView()); de kullanabilirsin, image ile "Send" in yerini deÄŸiÅŸtir bakalÄ±m nolacak

        btSend.setFont(Font.font("times new roman", FontWeight.BOLD, FontPosture.ITALIC,20));
        pane.add(btSend, 1, 2);
        ImageView send = new ImageView(); //fotoÄŸrafÄ± indirdiÄŸinde urlsini parantez iÃ§ine tÄ±rnaklar iÃ§inde yaz veya 4 satÄ±r yukarÄ± bak
        btSend.setOnAction(new EventHandler<ActionEvent>() {

            public void handle(ActionEvent arg0) {
                // TODO Auto-generated method stub
            	try {
					Message.Messages.createmessage(area.getText(), "HELP", 611, 611);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            	errorWindow.close();
            }
        });
        Scene sc = new Scene(pane);
        errorWindow.setOnCloseRequest(e -> {
            e.consume();
            Boolean answer = closing() ;
            if(answer) {
                errorWindow.close();
            }
        });
        area.setWrapText(true);
        // area.setEditable(false); ---> Saatlerimi boÅŸa harcamama sebep olan lanet kod. Ramazan'a bÃ¶yle gergin girmemeliydim.
        errorWindow.setScene(sc);
        errorWindow.setResizable(false);
        errorWindow.show();


    }
}
