package MyControls;

import Cashiers.Cashier;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.stage.Stage;

import javax.swing.*;

public class MyControl {

    public static Button MyButtonSK(String btnText) {
        Button btn = new Button(btnText);
        btn.setStyle("-fx-background-color: linear-gradient(#dc9656, #bd2c00)");
        return btn;
    }
    public static Button MyButtonSM(String btnText) {
        Button btn = new Button(btnText);
        btn.setStyle("-fx-background-color: linear-gradient(#dc9656, #00cccc)"); // #dc9656, #e2725b
        return btn;
    }

    public static TextField MyTextField(String promtText) {  // Prompt'a sahip textfieldlar için!!!
        TextField txt = new TextField();
        txt.setPromptText(promtText);
        return txt;
    }
    public static TextField MyTextFieldRedText(String promtText) {  // Prompt'a sahip kırmızı yazan textfieldler için!!!
        TextField txt = new TextField();
        txt.setPromptText(promtText);
        txt.setStyle("-fx-text-inner-color: red");
        return txt;
    }

    public static PasswordField MyPasswordFieldRedText(String promtText) {  // Prompt'a sahip kırmızı yazan PasswordFieldler için!!!
        PasswordField txt = new PasswordField();
        txt.setPromptText(promtText);
        txt.setStyle("-fx-text-inner-color: red");
        return txt;
    }

    public static MenuBar MyMenuBar() {
        MenuBar bar = new MenuBar();
        bar.setStyle("-fx-background-color: linear-gradient(#dc9656, #bd2c00)");
        return bar;
    }
    public static BorderPane MyBorderPane() {
        BorderPane pane = new BorderPane();
        pane.setStyle("-fx-background-color: #282828");
        return pane;
    }
    public static GridPane MyGridPane() {
        GridPane pane = new GridPane();
        pane.setStyle("-fx-background-color: #282828");
        return pane;
    }
    public static Stage MyStage(String title) {
        Stage add = new Stage();
        add.setTitle(title);
        return add;
    }
    public static Label MyLabelLime(String title) {
        Label label = new Label(title);
        label.setTextFill(Color.LIME);
        return label;
    }
    public static Label MyLabelUnderlined(String title) {
        Label label = new Label(title);
        label.setTextFill(Color.AZURE);
        label.setUnderline(true);
        return label;
    }
    public static Label MyLabelYellowGreen() {
        Label label = new Label();

    label.setFont(Font.font("times new roman", FontPosture.ITALIC, 17));
        label.setTextFill(Color.YELLOWGREEN);
        return label;
    }
    public static <T> TableColumn MyTableColumn(String title) {
        TableColumn<T, String> column = new TableColumn<>(title);
        column.setCellValueFactory(new PropertyValueFactory<>(title));
        column.setMinWidth(200);
        return column;
    }
 public static <T> TableColumn MyTableColumn2(String title) {
        TableColumn<T, String> column = new TableColumn<>(title);
        column.setCellValueFactory(new PropertyValueFactory<>(title));
        column.setMinWidth(100);
        return column;
    }

}
