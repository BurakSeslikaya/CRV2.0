package Cashiers;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;

public class PasswordC {


    public static int Write(String name ,String pas) throws Exception {

        File file = new File("Passw.txt");
        BufferedReader bfr = new BufferedReader(new FileReader(file));
        ArrayList<String> arl = new ArrayList<String>();
        String oldValues;
        while((oldValues = bfr.readLine()) != null){
            arl.add(oldValues);
        }
        bfr.close();
        boolean a;
        if((a = arl.contains(name)) == true ) {
            return 0; //    Bu kullanÄ±cÄ± Ã¶nceden oluÅŸturulmuÅŸ.
        }
        if((name.isEmpty()) == true){
            return 0;
        }
        else {
            BufferedWriter writing = new BufferedWriter(new FileWriter(file));
            int size;
            size = arl.size();
            String tm, fnl;
            for(int f = 0; f < size; f++) {
                tm = arl.get(f);
                writing.write(tm);
                writing.newLine();
            }
            writing.write(name);
            writing.newLine();
            writing.write(pas);
            writing.newLine();
            int ishemanager = 0;
            if(size  == 0) {
                writing.write("611");
                ishemanager++;

            }
            else {
                size = Integer.parseInt(arl.get(size - 1));
                size++;
                fnl = Integer.toString(size);
                writing.write(fnl);
            }
            writing.newLine();
            writing.close();
            File file2 = new File("Authorization.txt");
            ArrayList<String> arl2 = new ArrayList<String>();
            String oldValues2;
            if(ishemanager == 1) {
                BufferedWriter bfra2 = new BufferedWriter(new FileWriter(file2));
                bfra2.write("611");
                bfra2.newLine();
                for(int f = 0; f < 8; f++) {//   
                    bfra2.write("1");// toplam 9 adet bÃ¶lme var
                    bfra2.newLine();
                }
                bfra2.close();
            }
            else {
                BufferedReader bfra = new BufferedReader(new FileReader(file2));
                while((oldValues2 = bfra.readLine()) != null){
                    arl2.add(oldValues2);
                }
                bfra.close();
                BufferedWriter bfra2 = new BufferedWriter(new FileWriter(file2));
                int size2 = arl2.size();
                for(int f = 0; f < size2; f++) {
                    tm = arl2.get(f);
                    bfra2.write(tm);
                    bfra2.newLine();
                }
                bfra2.write(Integer.toString(size));
                bfra2.newLine();
                for(int f = 0; f < 8; f++) {  
                    bfra2.write("0");
                    bfra2.newLine();
                }
                bfra2.close();
            }
            return 1;  //  KullanÄ±cÄ± baÅŸarÄ± ile oluÅŸturuldu.
        }
    }

    //      0 HATALI Å�Ä°FRE VEYA KULLANICI ADI      sayÄ±(hangi kullanÄ±cÄ±) giriÅŸe izin verildi
    public static int log(String name, String pass) throws Exception  {
        int permission = 0, abd, r, o;
        File file = new File("Passw.txt");
        BufferedReader reading = new BufferedReader(new FileReader(file));
        String oldValues, Ts;
        ArrayList<String> set = new ArrayList<String>();
        while((oldValues = reading.readLine()) != null){
            set.add(oldValues);
        }
        reading.close();
        boolean a , b;
        if((a = set.contains(name)) == true) {
            o = set.indexOf(name);
            if(((Ts = set.get(o + 1)).equals(pass))){
                Ts = set.get(o + 2);
                abd = Integer.parseInt(Ts);
                return abd;
            }
            else {
                return 0;
            }
        }
        else {
            return 0;
        }
    }

    // 0 kullan
    public static ArrayList<String> get(String id) throws Exception {
        File file = new File("Passw.txt");
        BufferedReader bfrd = new BufferedReader(new FileReader(file));
        ArrayList<String> arl = new ArrayList<String>();
        String a;
        while((a = bfrd.readLine()) != null) {
            arl.add(a);
        }
        if(id == "0") {
            bfrd.close();
            return arl;
        }
        else {
            int ab;
            ArrayList<String> arl2 = new ArrayList<String>();
            ab = arl.indexOf(id);
            ab = ab - 2;
            for(int y = 0; y < 3; y++) {
                arl2.add(arl.get(ab));
                ab++;
            }
            bfrd.close();
            return arl2;
        }
    }

    //0 DELETE    1 CHANGE
    public static void pasChange(String systemid ,String Name, String pass, int deleteOrChange) throws Exception {
        File file = new File("Passw.txt");
        BufferedReader bfrd = new BufferedReader(new FileReader(file));
        ArrayList<String> arl = new ArrayList<String>();
        String oldValues;
        while((oldValues = bfrd.readLine()) != null){
            arl.add(oldValues);
        }
        bfrd.close();
        int WhichOne, c;
        WhichOne = arl.indexOf(systemid);
        arl.remove(WhichOne - 2);
        arl.remove(WhichOne - 2);
        if(deleteOrChange == 0) {
            BufferedWriter bfrW = new BufferedWriter(new FileWriter(file));
            arl.remove(WhichOne - 2);
            c = arl.size();
            for(int t = 0; t < c; t++) {
                bfrW.write(arl.get(t));
                bfrW.newLine();
            }
            bfrW.close();
            File file2 = new File("Authorization.txt");
            BufferedReader bfr = new BufferedReader(new FileReader(file2));
            ArrayList<String> arl2 = new ArrayList<String>();
            String oldValues2;
            while((oldValues2 = bfr.readLine()) != null){
                arl2.add(oldValues2);
            }
            bfr.close();
            BufferedWriter bfrw = new BufferedWriter(new FileWriter(file2));
            int size = arl2.size();
            for(int f = 0; f < size; f++) {
                oldValues2 = arl2.get(f);
                if(oldValues2.equals(systemid)) {
                    f = f + 9;
                    continue;
                }
                bfrw.write(oldValues2);
                bfrw.newLine();
            }
            bfrw.close();
        }
        else {
            BufferedWriter bfWr = new BufferedWriter(new FileWriter(file));
            int h;
            arl.add(WhichOne - 2, Name);
            arl.add(WhichOne - 1, pass);
            h = arl.size();
            for(int forint = 0; forint < h; forint++) {
                bfWr.write(arl.get(forint));
                bfWr.newLine();
            }
            bfWr.close();
        }
    }
}