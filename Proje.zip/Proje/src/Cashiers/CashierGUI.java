package Cashiers;

import MyControls.MyControl;
import MyControls.MyMessages;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.stage.Stage;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class CashierGUI {

    public static void CashierList(){
        Stage pencere = MyControl.MyStage("Cashiers");
        TableView<Cashier> table = new TableView<>();

        TableColumn<Cashier, String> column1 = MyControl.MyTableColumn("Name");
        TableColumn<Cashier, String> column2 = MyControl.MyTableColumn("Password");
        TableColumn<Cashier, String> column3 = MyControl.MyTableColumn("SystemID");

        table.getColumns().addAll(column1, column2, column3); // Kolonları ekledik
        table.setItems(CashierService.cashiers);

        TextField inputName = MyControl.MyTextFieldRedText("name : johndoe");
        TextField inputPassword = MyControl.MyTextFieldRedText("password : 345542");
        inputPassword.setMinWidth(200);

        Button addButton = new Button("Add");
        Button deleteButton = new Button("Delete");
        HBox hbox = new HBox(13);
        hbox.setPadding(new Insets(10, 10, 10, 10));
        hbox.setSpacing(10);
        hbox.getChildren().addAll(inputName, inputPassword, addButton, deleteButton);

        addButton.setOnAction(E -> {

            String name = inputName.getText();
            String password = inputPassword.getText();
            if (CashierService.addCashier(name, password)) {
            	try {
            	File file2 = new File("Authorization.txt");
                ArrayList<String> arl2 = new ArrayList<String>();
                String oldValues2;
                if(CashierService.KasiyerBul(password).getSystemID().equals("611")) {
                    BufferedWriter bfra2 = new BufferedWriter(new FileWriter(file2));
                    bfra2.write("611");
                    bfra2.newLine();
                    for(int f = 0; f < 8; f++) {//   
                        bfra2.write("1");// toplam 9 adet bölme var
                        bfra2.newLine();
                    }
                    bfra2.close();
                }
                else {
                    BufferedReader bfra = new BufferedReader(new FileReader(file2));
                    while((oldValues2 = bfra.readLine()) != null){
                        arl2.add(oldValues2);
                    }
                    bfra.close();
                    BufferedWriter bfra2 = new BufferedWriter(new FileWriter(file2));
                    int size2 = arl2.size();
                    String tm;
                    for(int f = 0; f < size2; f++) {
                        tm = arl2.get(f);
                        bfra2.write(tm);
                        bfra2.newLine();
                    }
                    bfra2.write(CashierService.KasiyerBul(password).getSystemID());
                    bfra2.newLine();
                    for(int f = 0; f < 8; f++) {  
                        bfra2.write("0");
                        bfra2.newLine();
                    }
                    bfra2.close();
                }
            	}catch(Exception e) {
            		e.printStackTrace();
            	}
            }

            inputName.clear();
            inputPassword.clear();


        });

        deleteButton.setOnAction(D -> {
            ObservableList<Cashier> selectedCashier = table.getSelectionModel().getSelectedItems();
            //	 selectedCashier.forEach(CashierService.cashiers::remove);

            selectedCashier.forEach(c -> {
            	
            	try {
                    File file2 = new File("Authorization.txt");
                    BufferedReader bfr = new BufferedReader(new FileReader(file2));
                    ArrayList<String> arl2 = new ArrayList<String>();
                    String oldValues2;
                    while((oldValues2 = bfr.readLine()) != null){
                        arl2.add(oldValues2);
                    }
                    bfr.close();
                    BufferedWriter bfrw = new BufferedWriter(new FileWriter(file2));
                    int size = arl2.size();
                    for(int f = 0; f < size; f++) {
                        oldValues2 = arl2.get(f);
                        if(oldValues2.equals(c.getSystemID())) {
                            f = f + 9;
                            continue;
                        }
                        bfrw.write(oldValues2);
                        bfrw.newLine();
                    }
                    bfrw.close();
                    }catch(Exception e){
                    	e.printStackTrace();
                    }
            	
                if (c.getSystemID().equals("611")) {
                    MyMessages.errorMessage("ATTENTION", "You cannot delete manager.");
                }
                //	 if(!c.getSystemID().equals("611")) {
                else {
                    selectedCashier.forEach(CashierService.cashiers::remove);
                    try {
                        CashierService.KasiyerListesiKaydet();
                    } catch (IOException e1) {
                        // TODO Auto-generated catch block
                        e1.printStackTrace();
                        MyMessages.errorMessage("Bir sey oldu", "Kasiyer silinirken bir hata gelisti.");
                    }
                }

            });

        });

        VBox vbox = new VBox();
        vbox.getChildren().addAll(table, hbox);
        Scene sc = new Scene(vbox);
        table.setStyle("-fx-background-color: #282828");
        vbox.setStyle("-fx-background-color: #282828");
        pencere.setResizable(false);
        pencere.setScene(sc);
        pencere.show();

    }
    public  static void CashierAdd(){
        try {// Burak'ın attığı koddan buraya çağırıcam.
            // Aynılarını diğer itemler için de yapıcam.

            Stage add = MyControl.MyStage("Cashier adding");
            GridPane addPane = new GridPane();
            addPane.setAlignment(Pos.CENTER);
            addPane.setStyle("-fx-background-color: #282828");
            addPane.setPadding(new Insets(13, 13, 13, 13));
            Label lbname = new Label("New Cashier's Name: ");
            lbname.setTextFill(Color.LIME);
            addPane.add(lbname, 0, 0);
            TextField tfname = new TextField();
            addPane.add(tfname, 1, 0);
            Label lbpas = new Label("New Cashier's Password: ");
            lbpas.setTextFill(Color.LIME);
            addPane.add(lbpas, 0, 1);
            TextField tfpas = new TextField();
            addPane.add(tfpas, 1, 1);
            Button addButton = MyControl.MyButtonSK("Add Cashier.");

            addPane.add(addButton, 1, 2);
            GridPane.setHalignment(addButton, HPos.RIGHT);
            addButton.setOnAction(new EventHandler<ActionEvent>() {
                public void handle(ActionEvent arg0) {
                    try {
                        String name = tfname.getText();
                        String pas = tfpas.getText();
                        int a = PasswordC.Write(name, pas);
                        // System.out.println(a);
                        if (a == 0) {
                            tfname.clear();
                            tfpas.clear();
                            addPane.add(BottomMessage("Not unique name adding. Please change the name."), 0, 3, 3, 3);

                        } else {
                            tfname.clear();
                            tfpas.clear();
                            addPane.add(BottomMessage("Cashier is added succesfully."), 0, 3, 3, 3);
                        }
                    } catch (Exception e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
            });

            addPane.setPadding(new Insets(10, 10, 10, 10)); // pane'in kenarlarındaki boşlukları ayarladık
            addPane.setHgap(5);
            addPane.setVgap(5);
            Scene sc = new Scene(addPane, 400, 200);
            add.setScene(sc);
            add.show();

        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    public static void CashierRemove(){
        try {

            Stage remove = MyControl.MyStage("Cashier removing");
            GridPane removePane = MyControl.MyGridPane();
            removePane.setAlignment(Pos.CENTER);
            removePane.setPadding(new Insets(13, 13, 13, 13));
            Label lbname = MyControl.MyLabelLime("Cashier's Name Who Will be Removed: ");
            removePane.add(lbname, 0, 0);
            TextField tfname = new TextField();
            removePane.add(tfname, 1, 0);
            Label lbpas = MyControl.MyLabelLime("Cashier's Password Who Will be Removed: ");
            removePane.add(lbpas, 0, 1);
            TextField tfpas = new TextField();
            removePane.add(tfpas, 1, 1);
            Label Lbsystemid = MyControl.MyLabelLime("Cashier's ID Who Will be Removed: ");
            removePane.add(Lbsystemid, 0, 2);
            TextField tfSystemId = new TextField();
            removePane.add(tfSystemId, 1, 2);
            Button removeButton = MyControl.MyButtonSK("Remove.");

            GridPane.setHalignment(removeButton, HPos.RIGHT);
            removePane.add(removeButton, 1, 3);
            removeButton.setOnAction(new EventHandler<ActionEvent>() {
                public void handle(ActionEvent arg0) {
                    try {
                        String systemid = tfSystemId.getText();
                        String Name = tfname.getText();
                        String pass = tfpas.getText();

                        if (CashierService.kasiyerBilgileriDogruMu(Name, pass, systemid)) {
                            int deleteOrChange = 0;
                            PasswordC.pasChange(systemid, Name, pass, deleteOrChange);
                            tfSystemId.clear();
                            tfname.clear();
                            tfpas.clear();
                            removePane.add(BottomMessage("Cashier is removed."), 0, 4, 4, 4); // kasiyer bilgilerini dğru
                            // girince çalışıyor ama
                            // uyumsuz girince error
                            // veriyor
                        }
                        if (!CashierService.kasiyerBilgileriDogruMu(Name, pass, systemid)) {
                            MyMessages.errorMessage("ERROR", "Cashier's informations must be accurate");
                            tfSystemId.clear();
                            tfname.clear();
                            tfpas.clear();
                        }
                    } catch (Exception e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                        MyMessages.errorMessage("HATA", "Cashier Removing kismi etkinlesirken hata gelisti");
                    }
                }
            });

            removePane.setPadding(new Insets(10, 10, 10, 10));
            removePane.setHgap(5);
            removePane.setVgap(5);
            Scene sc = new Scene(removePane, 500, 200);
            remove.setScene(sc);
            remove.show();

        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            MyMessages.errorMessage("HATA", "Cashier Removing kismi etkinlesirken hata gelisti");
        }
    }

    private static HBox BottomMessage(String message) {
        HBox pencere = new HBox(13);
        pencere.setPadding(new Insets(13, 13, 13, 13));
        Label hesap = new Label(message);
        pencere.getChildren().add(hesap);
        hesap.setTextFill(Color.BLACK);
        hesap.setFont(Font.font("times new roman", FontPosture.ITALIC, 13));
        pencere.setStyle("-fx-background-color: linear-gradient(#dc9656, #00cccc)");
        return pencere;
    }

}
