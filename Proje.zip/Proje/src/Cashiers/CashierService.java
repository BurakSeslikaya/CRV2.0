package Cashiers;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.*;
import java.nio.file.*;

import MyControls.MyMessages;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;


import static java.nio.file.StandardCopyOption.REPLACE_EXISTING;

public class CashierService {

    public static String CashierId = "";
    public static ObservableList<Cashier> cashiers = null;

    public static Cashier KasiyerBul(String password) {
        for (Cashier s : cashiers) {
            if (s.getPassword().equals(password)) {
                return s;
            }
        }
        return null;
    }

    public static ObservableList<Cashier> getCashiersFromTXTtoListPass() {
        // txt'den çekilen bilgileri cashier'a atıyor
        cashiers = FXCollections.observableArrayList();

        int i = 0;
        ArrayList<String> list = null;

        try {
             list = PasswordC.get("0");
             Cashier kasiyer = new Cashier();

             for (String s:list){
                  i = i + 1;

                if (i == 1) {
                    kasiyer = new Cashier();
                    kasiyer.setName(s);
                } else if (i == 2) {
                    kasiyer.setPassword(s);
                } else if (i == 3) {
                    kasiyer.setSystemID(s);
                    cashiers.add(kasiyer);
                    i = 0;
                }

            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return cashiers;

    }
    public static boolean CashierFind(String name, String password) {  //Ksiyer eklemede son verilen idyi buluyor

        int Success = 0;
        try {
            Success = PasswordC.log(name, password);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if(Success == 0){
            MyMessages.errorMessage("HATA", "Kulanici adi veya sifre hatali");
            return false;
        }
        for (Cashier sid : cashiers) {
            if(sid.getName().equals(name) && sid.getPassword().equals(password)){
                CashierId = sid.getSystemID();
                return true;
            }

        }
        return true;
    }
    public static String idFind() {  //Ksiyer eklemede son verilen idyi buluyor
        int id = 100;
        if (cashiers.size() == 0) {
            id = 610;
        }
        int id2 = 100;
        for (Cashier sid : cashiers) {
            id2 = Integer.parseInt(sid.getSystemID());
            if (id2 > id) {
                id = id2;
            }
        }
        return String.valueOf(id + 1);
    }

    public static boolean addCashier(String name, String password) {
        try {
            boolean varmi = false;
            for (Cashier s : cashiers) {
                if (s.getName().equals(name)) {
                    varmi = true;
                }
            }
            if (varmi == false) {

                Cashier ekle = new Cashier();
                ekle.setPassword(password);
                ekle.setName(name);
                ekle.setSystemID(idFind());
                cashiers.add(ekle);
                addCashierClass(ekle);
                return true;
            } else {
                MyMessages.errorMessage("CAUTION", "You Cannot Add Not-Unique Cashier. Please check the informations of cashier.");
                return false;
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return false;
        }

    }

    public static void addCashierClass(Cashier s) {
        String id = idFind();
        Path p = Paths.get("Passw.txt");
        String st = "";

        try {
            st = s.getName() + System.lineSeparator();
            Files.write(p, st.getBytes(), StandardOpenOption.APPEND);
            st = s.getPassword() + System.lineSeparator();
            Files.write(p, st.getBytes(), StandardOpenOption.APPEND);
            st = id + System.lineSeparator();
            Files.write(p, st.getBytes(), StandardOpenOption.APPEND);
        } catch (IOException e) {
            System.err.println(e);
        }
    }

    public static void updateCashierClass(Cashier s) {

        Path p = Paths.get("Passw.txt");
        String st = "";

        try {
            st = s.getName() + System.lineSeparator();
            Files.write(p, st.getBytes(), StandardOpenOption.APPEND);
            st = s.getPassword() + System.lineSeparator();
            Files.write(p, st.getBytes(), StandardOpenOption.APPEND);
            st = s.getSystemID() + System.lineSeparator();
            Files.write(p, st.getBytes(), StandardOpenOption.APPEND);
        } catch (IOException e) {
            System.err.println(e);
        }
    }

    public static boolean KasiyerListesiKaydet() throws IOException {

        // eski dosyayı yedekle
        DosyaSil();
        // product listesini kaydet
        for (Cashier s : cashiers) {
            try {
                updateCashierClass(s);
                //PasswordC.Write(s.getName(), s.getPassword());
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

        return true;
    }

    private static void DosyaSil() throws IOException {
        // dosya 2 varsa sil dosyayı dosya yedek yap yedeklemiş olursun hataya karşı
        // bir şeyi yanlışlıkla sildiysen dosyayedekte eski hali var :)
        String yedek = "PasswYedek.txt";
        String dosya = "Passw.txt";
        File f = new File(yedek);
        if (f.exists()) {
            f.delete();
        }
        File f2 = new File(dosya);
        if (f2.exists()) {
            Path copy = Files.copy(f2.toPath(), f.toPath(), REPLACE_EXISTING);
            PrintWriter writer = new PrintWriter(dosya);
            writer.print("");
            writer.close();
        }
    }

    public static boolean kasiyerBilgileriDogruMu(String name, String password, String systemID) {
        try {
            boolean esmi = false;
            for (Cashier s : cashiers) {
                if (s.getPassword().equals(password)) {
                    if (s.getName().equals(name)) {
                        if (s.getSystemID().equals(systemID)) {
                            esmi = true;
                        }
                    }
                }
            }
            if (esmi == false) {
                MyMessages.errorMessage("CAUTION", "Something wrong. Please check the informations of cashier.");
                return true;
            } else {
                return true;
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return false;
        }
    }

    public static ObservableList<Cashier> YedekgetCashiersFromTXTtoList() {
        // txt'den çekilen bilgileri cashier'a atıyor
        cashiers = FXCollections.observableArrayList();

        int i = 0;
        Scanner s;
        try {
            s = new Scanner(new File("Passw.txt"));

            Cashier kasiyer = new Cashier();

            while (s.hasNext()) {
                i = i + 1;

                if (i == 1) {
                    kasiyer = new Cashier();
                    kasiyer.setName(s.nextLine());
                } else if (i == 2) {
                    kasiyer.setPassword(s.nextLine());
                } else if (i == 3) {
                    kasiyer.setSystemID(s.nextLine());
                    cashiers.add(kasiyer);
                    i = 0;
                }

            }
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return cashiers;

    }


}
