package Cashiers;

public class Cashier {
    private String name;
    private String password;
    private String systemID;


    public Cashier() {
    }

    public Cashier(String name,String password,String systemID) {
        this.name = name;
        this.password = password;
        this.systemID = systemID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    public String getSystemID() {
        return systemID;
    }
    public void setSystemID(String systemID) {
        this.systemID = systemID;
    }

}
